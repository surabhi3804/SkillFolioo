// SkillAnalytics.js — Module 4: Skill Analytics & Visualization
import { useState, useMemo } from "react";
import "./SkillAnalytics.css";

const DOMAIN_MAP = {
  "Web Dev":      ["javascript","typescript","react","vue","angular","html","css","node","next","redux","svelte","webpack","tailwind","graphql"],
  "Data Science": ["python","pandas","numpy","sql","tableau","power bi","r ","jupyter","statistics","data analysis","etl","spark","excel"],
  "AI / ML":      ["machine learning","deep learning","tensorflow","pytorch","keras","nlp","computer vision","neural","scikit","llm","bert","gpt"],
  "DevOps":       ["aws","azure","gcp","docker","kubernetes","ci/cd","terraform","jenkins","linux","bash","ansible","nginx","devops"],
  "Design":       ["figma","sketch","adobe xd","illustrator","photoshop","ui/ux","ux","user research","prototyping","wireframe","design system"],
  "Mobile":       ["react native","flutter","swift","kotlin","android","ios","mobile","expo"],
  "Database":     ["mysql","postgresql","mongodb","redis","sqlite","firebase","dynamodb","nosql","supabase"],
  "Soft Skills":  ["leadership","communication","teamwork","agile","scrum","project management","stakeholder","mentoring"],
};

const DOMAIN_COLORS = {
  "Web Dev":"#1B3A5C","Data Science":"#7A9BB5","AI / ML":"#C4948E",
  "DevOps":"#C4B09A","Design":"#A87C7C","Mobile":"#A8BCC8",
  "Database":"#8C5E5E","Soft Skills":"#E8D5CF","Other":"#D4C4B8",
};

const LEVEL_PCT = { Beginner:24, Intermediate:54, Advanced:80, Expert:95 };
const LEVELS    = ["Beginner","Intermediate","Advanced","Expert"];

function classify(name) {
  const l = name.toLowerCase();
  for(const [dom,kws] of Object.entries(DOMAIN_MAP))
    if(kws.some(k=>l.includes(k)||k.includes(l))) return dom;
  return "Other";
}

/* ── Radar SVG ── */
function RadarChart({ classified }) {
  const size = 200, cx = 100, cy = 100, r = 74;
  const keys = Object.keys(DOMAIN_MAP);
  const n    = keys.length;
  const C    = 2 * Math.PI;

  const maxVal = Math.max(...keys.map(k=>(classified[k]||[]).length), 3);

  function pt(i, v) {
    const angle = (C * i / n) - Math.PI/2;
    const d = r * (v / maxVal);
    return { x: cx + d*Math.cos(angle), y: cy + d*Math.sin(angle) };
  }
  function lbPt(i) {
    const angle = (C * i / n) - Math.PI/2;
    return { x: cx + (r+22)*Math.cos(angle), y: cy + (r+22)*Math.sin(angle) };
  }

  const GRID = [1,2,3,4,5];
  const vals = keys.map(k=>(classified[k]||[]).length);

  const poly = (vs) => vs.map((v,i)=>{ const p=pt(i,v); return `${p.x},${p.y}`; }).join(" ");
  const gridPoly = (lvl) => keys.map((_,i)=>{ const p=pt(i,lvl*maxVal/5); return `${p.x},${p.y}`; }).join(" ");

  return (
    <div className="sa-radar-wrap">
      <svg width={280} height={260} className="sa-radar-svg" viewBox="-40 -30 280 260">
        {GRID.map(l=><polygon key={l} className="sa-radar-grid" points={gridPoly(l)}/>)}
        {keys.map((_,i)=>{ const e=pt(i,maxVal); return <line key={i} className="sa-radar-axis" x1={cx} y1={cy} x2={e.x} y2={e.y}/>; })}
        <polygon className="sa-radar-area" points={poly(vals)}/>
        {vals.map((v,i)=>{ const p=pt(i,v); return <circle key={i} className="sa-radar-dot" cx={p.x} cy={p.y} r={4}/>; })}
        {keys.map((k,i)=>{ const lb=lbPt(i); return (
          <text key={i} className="sa-radar-lbl" x={lb.x} y={lb.y} textAnchor="middle" dominantBaseline="middle" fontSize={9}>
            {k.split("/")[0].trim().split(" ").slice(0,2).join(" ")}
          </text>
        );})}
      </svg>
    </div>
  );
}

/* ── Heatmap ── */
function HeatMap({ skills, classified }) {
  const [hov, setHov] = useState(null);
  const allDomains = Object.keys(DOMAIN_MAP).filter(d=>classified[d]);

  const grid = useMemo(()=>{
    const m = {};
    skills.forEach(s=>{
      const d = classify(s.name);
      const l = s.level||"Intermediate";
      if(!m[d]) m[d]={};
      m[d][l] = (m[d][l]||0)+1;
    });
    return m;
  },[skills]);

  if(!skills.length) return <div className="sa-empty">Add skills in Data Collection to see your heatmap.</div>;

  function cellBg(domain, level) {
    const count = grid[domain]?.[level]||0;
    if(!count) return "rgba(168,188,200,.1)";
    const col = DOMAIN_COLORS[domain]||"#7A9BB5";
    const op  = Math.min(.2+count*.22,.92);
    return col+(Math.round(op*255).toString(16).padStart(2,"0"));
  }

  return (
    <div className="sa-heatmap-wrap">
      <div className="sa-heat-row" style={{marginBottom:6}}>
        <div style={{width:113}}/>
        {LEVELS.map(l=><div key={l} className="sa-heat-col-lbl">{l}</div>)}
      </div>
      {allDomains.map(domain=>(
        <div key={domain} className="sa-heat-row">
          <div className="sa-heat-row-lbl">{domain}</div>
          {LEVELS.map(level=>{
            const count = grid[domain]?.[level]||0;
            const cid   = `${domain}-${level}`;
            return (
              <div key={level} className="sa-heat-cell"
                style={{ background:cellBg(domain,level), transform:hov===cid&&count?"scale(1.15)":"scale(1)", color:count>1?"rgba(255,255,255,.9)":"transparent" }}
                onMouseEnter={()=>setHov(cid)} onMouseLeave={()=>setHov(null)}
                title={count?`${count} ${level} skill${count>1?"s":""} in ${domain}`:"None"}>
                {count>0?count:""}
              </div>
            );
          })}
        </div>
      ))}
      <div className="sa-heat-legend">
        <span className="sa-heat-legend-lbl">Less</span>
        {[.1,.3,.5,.7,.9].map((o,i)=><div key={i} style={{width:18,height:18,background:`rgba(27,58,92,${o})`,borderRadius:2}}/>)}
        <span className="sa-heat-legend-lbl">More</span>
      </div>
    </div>
  );
}

/* ── Demo data ── */
const DEMO = [
  {id:"1",name:"JavaScript",level:"Expert"},{id:"2",name:"React",level:"Expert"},
  {id:"3",name:"Python",level:"Advanced"},{id:"4",name:"Figma",level:"Advanced"},
  {id:"5",name:"SQL",level:"Intermediate"},{id:"6",name:"Machine Learning",level:"Intermediate"},
  {id:"7",name:"AWS",level:"Beginner"},{id:"8",name:"UI/UX",level:"Expert"},
  {id:"9",name:"TypeScript",level:"Advanced"},{id:"10",name:"Docker",level:"Intermediate"},
  {id:"11",name:"Node.js",level:"Advanced"},{id:"12",name:"MongoDB",level:"Intermediate"},
  {id:"13",name:"Leadership",level:"Advanced"},{id:"14",name:"TensorFlow",level:"Beginner"},
];

export default function SkillAnalytics({ skills: propSkills }) {
  const [tab, setTab] = useState("overview");
  const skills = propSkills?.length ? propSkills : DEMO;

  const classified = useMemo(()=>{
    const m={};
    skills.forEach(s=>{ const d=classify(s.name); if(!m[d])m[d]=[]; m[d].push(s); });
    return m;
  },[skills]);

  const domains   = Object.keys(classified).sort((a,b)=>classified[b].length-classified[a].length);
  const topSkills = [...skills].sort((a,b)=>(LEVEL_PCT[b.level]||50)-(LEVEL_PCT[a.level]||50)).slice(0,10);

  return (
    <div className="sa-page fade-up">
      <div className="sa-head">
        <span className="sec-tag">Module 4</span>
        <h2 className="sec-title">Skill <em>Analytics</em></h2>
        <p className="sec-sub">Your skills categorized into technical domains with visual insights.</p>
      </div>

      {/* Stat strip */}
      <div className="sa-stats">
        <div className="stat-card navy"><div className="stat-num">{skills.length}</div><div className="stat-label">Total Skills</div></div>
        <div className="stat-card windy"><div className="stat-num">{domains.length}</div><div className="stat-label">Domains</div></div>
        <div className="stat-card blush"><div className="stat-num">{skills.filter(s=>s.level==="Expert"||s.level==="Advanced").length}</div><div className="stat-label">Advanced+</div></div>
        <div className="stat-card linwood"><div className="stat-num">{domains[0]?.split("/")[0].trim().split(" ")[0]||"—"}</div><div className="stat-label">Top Domain</div></div>
      </div>

      {/* Tabs */}
      <div className="sa-tabs tabs">
        {["overview","heatmap","domains","top skills"].map(t=>(
          <button key={t} className={`tab-btn${tab===t?" active":""}`} onClick={()=>setTab(t)}>{t}</button>
        ))}
      </div>

      {/* Overview */}
      {tab==="overview" && (
        <div className="sa-grid-2">
          <div className="sa-card">
            <div className="sa-card-title">Domain Radar <span className="badge badge-windy">Spider</span></div>
            <RadarChart classified={classified}/>
          </div>
          <div className="sa-card">
            <div className="sa-card-title">Domain Distribution <span className="badge badge-blush">Bar</span></div>
            {domains.slice(0,7).map(dom=>{
              const cnt = classified[dom].length;
              const pct = Math.round(cnt/skills.length*100);
              return (
                <div key={dom} className="sa-bar-item">
                  <div className="sa-bar-head">
                    <span className="sa-bar-name">{dom}</span>
                    <span className="sa-bar-pct">{cnt} · {pct}%</span>
                  </div>
                  <div className="prog-track">
                    <div className="prog-fill" style={{width:`${pct}%`,background:DOMAIN_COLORS[dom]}}/>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Heatmap */}
      {tab==="heatmap" && (
        <div className="sa-card">
          <div className="sa-card-title">Skill Heatmap <span className="badge badge-navy">Domain × Level</span></div>
          <p style={{fontSize:12,color:"rgba(27,58,92,.52)",marginBottom:18}}>Intensity shows number of skills at each proficiency level per domain.</p>
          <HeatMap skills={skills} classified={classified}/>
        </div>
      )}

      {/* Domains */}
      {tab==="domains" && (
        <div className="sa-domains-grid">
          {domains.map((dom,i)=>(
            <div key={dom} className="sa-domain-card" style={{borderLeftColor:DOMAIN_COLORS[dom]||"var(--windy)",animationDelay:`${i*.06}s`}}>
              <div className="sa-domain-name">{dom}</div>
              <div className="sa-domain-count">{classified[dom].length} skill{classified[dom].length!==1?"s":""}</div>
              <div className="sa-domain-skills">
                {classified[dom].map(s=>(
                  <span key={s.id} className="sa-skill-tag">{s.name} <span style={{fontSize:9,opacity:.5}}>· {s.level?.slice(0,3)}</span></span>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Top skills */}
      {tab==="top skills" && (
        <div className="sa-card">
          <div className="sa-card-title">Top Skills by Proficiency <span className="badge badge-blush">Ranked</span></div>
          {topSkills.map((skill,i)=>{
            const pct = LEVEL_PCT[skill.level]||50;
            const dom = classify(skill.name);
            return (
              <div key={skill.id} className="sa-bar-item">
                <div className="sa-bar-head">
                  <div><span className="sa-bar-name">{skill.name}</span><div className="sa-bar-sub">{dom}</div></div>
                  <div style={{textAlign:"right"}}><span className="sa-bar-pct">{pct}%</span><div className="sa-bar-sub">{skill.level}</div></div>
                </div>
                <div className="prog-track">
                  <div className="prog-fill" style={{width:`${pct}%`,background:DOMAIN_COLORS[dom]}}/>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}