// TemplateSelector.js — Module 1
import { useState } from "react";
import "./TemplateSelector.css";

const TEMPLATES = [
  { id:"executive", name:"Executive", type:"Corporate", color:"#1B3A5C", accent:"#7A9BB5",
    desc:"Authoritative two-column layout for senior roles and C-suite applications.",
    tags:["ATS Ready","Two-Column","Professional"], industries:["Finance","Law","Engineering"], isPro:false },
  { id:"coastal", name:"Coastal", type:"Creative", color:"#7A9BB5", accent:"#C4B09A",
    desc:"Airy sidebar layout with soft tones — ideal for designers and creatives.",
    tags:["ATS Ready","Sidebar","Modern"], industries:["Design","Marketing","Media"], isPro:false },
  { id:"dusk", name:"Dusk", type:"Modern", color:"#C4948E", accent:"#1B3A5C",
    desc:"Bold colored header and warm accents for a sharp contemporary look.",
    tags:["ATS Ready","Bold Header","Accent"], industries:["Tech","Startups","Product"], isPro:true },
  { id:"sandstone", name:"Sandstone", type:"Minimal", color:"#C4B09A", accent:"#A87C7C",
    desc:"Refined spacing and subtle warmth — timeless layout for any industry.",
    tags:["ATS Ready","Minimal","Classic"], industries:["Academia","Research","Consulting"], isPro:false },
  { id:"blueprint", name:"Blueprint", type:"Corporate", color:"#1B3A5C", accent:"#A8BCC8",
    desc:"Vertical accent bar with clean hierarchy — strong impression for finance.",
    tags:["ATS Ready","Accent Bar","Clean"], industries:["Finance","Banking","Insurance"], isPro:true },
  { id:"rosewood", name:"Rosewood", type:"Modern", color:"#A87C7C", accent:"#E8D5CF",
    desc:"Photo-ready header with rose accents for creative professionals.",
    tags:["Photo Ready","Elegant","Warm"], industries:["Fashion","PR","Events"], isPro:true },
];

const FILTERS = ["All","Corporate","Creative","Modern","Minimal"];

function PaperThumb({ tpl }) {
  const { color, accent, id } = tpl;

  if (id === "coastal") return (
    <div className="paper-preview" style={{ background:"#fff", flexDirection:"row", gap:8 }}>
      <div className="paper-left-col" style={{ background:`${color}0d`, padding:10 }}>
        <div className="paper-name-line" style={{ background:color, width:"70%" }} />
        <div className="paper-role-line" style={{ background:accent }} />
        <div className="paper-divider" />
        {[100,85,90,75].map((w,i)=><div key={i} className="paper-body-line" style={{width:`${w}%`,background:color}}/>)}
      </div>
      <div className="paper-right-col" style={{ padding:"10px 0" }}>
        {[100,88,95,78,92,82].map((w,i)=><div key={i} className="paper-body-line" style={{width:`${w}%`,background:color}}/>)}
      </div>
    </div>
  );

  if (id === "blueprint") return (
    <div className="paper-preview" style={{ background:"#fff", flexDirection:"row" }}>
      <div className="paper-accent-bar" style={{ background:color }} />
      <div style={{ flex:1, padding:12 }}>
        <div className="paper-name-line" style={{ background:color }} />
        <div className="paper-role-line" style={{ background:accent }} />
        <div className="paper-divider" />
        {[100,88,95,80,92].map((w,i)=><div key={i} className="paper-body-line" style={{width:`${w}%`,background:color}}/>)}
      </div>
    </div>
  );

  return (
    <div className="paper-preview">
      <div className="paper-header-block" style={{ background:color }}>
        <div className="paper-name-line" style={{ background:"rgba(255,255,255,.85)" }} />
        <div className="paper-role-line" style={{ background:"rgba(255,255,255,.45)" }} />
      </div>
      <div style={{ display:"flex", gap:10, flex:1 }}>
        {(id==="executive"||id==="dusk") && (
          <div style={{ width:"36%", background:`${color}0a`, padding:"8px 8px 8px 0" }}>
            {[70,55,80,65].map((w,i)=><div key={i} className="paper-body-line" style={{width:`${w}%`,background:color}}/>)}
          </div>
        )}
        <div style={{ flex:1 }}>
          {[100,88,95,80,92,85].map((w,i)=><div key={i} className="paper-body-line" style={{width:`${w}%`,background:color}}/>)}
        </div>
      </div>
    </div>
  );
}

export default function TemplateSelector({ selectedId, onSelect }) {
  const [filter, setFilter]   = useState("All");
  const [preview, setPreview] = useState(null);

  const visible = TEMPLATES.filter(t => filter==="All" || t.type===filter);

  return (
    <div className="tpl-page fade-up">

      {/* Header */}
      <div className="tpl-header">
        <div className="tpl-header-left">
          <span className="sec-tag">Step 1 of 6</span>
          <h2 className="sec-title">Choose your <em>template</em></h2>
          <p className="sec-sub">Every template is ATS-optimized and dynamically populated with your data.</p>
        </div>
        <div className="tpl-header-right">
          <div className="tpl-count-num">{TEMPLATES.length}</div>
          <div className="tpl-count-label">Templates</div>
          <div className="tpl-count-sub">Pro templates included</div>
        </div>
      </div>

      {/* Filters */}
      <div className="tpl-filters">
        {FILTERS.map(f => (
          <button key={f} className={`filter-chip${filter===f?" active":""}`} onClick={()=>setFilter(f)}>
            {f}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="tpl-grid">
        {visible.map((tpl, i) => {
          const sel = selectedId === tpl.id;
          return (
            <div
              key={tpl.id}
              className={`tpl-card${sel?" selected":""}`}
              style={{ animationDelay:`${i*0.07}s` }}
            >
              {/* Thumb */}
              <div className="tpl-thumb" style={{ background:`linear-gradient(135deg,${tpl.color}12,${tpl.accent}1a)` }}>
                <PaperThumb tpl={tpl} />
                <div className="tpl-thumb-overlay">
                  <button className="btn btn-blush btn-sm" onClick={()=>onSelect(tpl)}>Use Template</button>
                  <button className="btn btn-ghost btn-sm" onClick={()=>setPreview(tpl)}>Preview</button>
                </div>
                <div className="tpl-type-badge" style={{ background:tpl.color }}>{tpl.type}</div>
                {tpl.isPro && <div className="tpl-pro-badge">PRO</div>}
                {sel && <div className="tpl-check">✓</div>}
              </div>

              {/* Info */}
              <div className="tpl-info">
                <div className="tpl-card-type">{tpl.type}</div>
                <div className="tpl-card-name">{tpl.name}</div>
                <div className="tpl-card-desc">{tpl.desc}</div>
                <div className="tpl-card-tags">
                  {tpl.tags.map(t=><span key={t} className="badge badge-windy">{t}</span>)}
                </div>
                <div className="tpl-card-industries">Best for: {tpl.industries.join(" · ")}</div>
                <div className="tpl-card-actions">
                  <button className="tpl-use-btn" style={{ background:tpl.color }} onClick={()=>onSelect(tpl)}>
                    {sel ? "✓ Selected" : "Use This"}
                  </button>
                  <button className="tpl-preview-btn" onClick={()=>setPreview(tpl)}>Preview</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Preview modal */}
      {preview && (
        <div className="modal-bg" onClick={()=>setPreview(null)}>
          <div className="modal-box" onClick={e=>e.stopPropagation()}>
            <div className="modal-head">
              <div>
                <div className="tpl-card-type">{preview.type}</div>
                <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:24, fontWeight:500, color:"var(--naval)" }}>
                  {preview.name} Template
                </div>
              </div>
              <button className="modal-close" onClick={()=>setPreview(null)}>×</button>
            </div>
            <div className="modal-body">
              <div style={{ height:260, background:`linear-gradient(135deg,${preview.color}10,${preview.accent}18)`,
                display:"flex", alignItems:"center", justifyContent:"center", marginBottom:20 }}>
                <div style={{ width:220, height:200, boxShadow:"var(--shadow-lg)" }}>
                  <PaperThumb tpl={preview} />
                </div>
              </div>
              <p style={{ fontSize:14, color:"rgba(27,58,92,.65)", lineHeight:1.75, marginBottom:14 }}>{preview.desc}</p>
              <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:12 }}>
                {preview.tags.map(t=><span key={t} className="badge badge-windy">{t}</span>)}
              </div>
              <div className="tpl-card-industries">Best for: {preview.industries.join(", ")}</div>
            </div>
            <div className="modal-foot">
              <button className="btn btn-outline" onClick={()=>setPreview(null)}>Cancel</button>
              <button className="btn btn-navy" onClick={()=>{ onSelect(preview); setPreview(null); }}>
                Use This Template
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}