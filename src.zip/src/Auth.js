// Auth.js — Login/Signup Modal (connected to backend)
import { useState, useRef, useEffect } from "react";
import { authAPI } from "./api";
import "./Auth.css";

function getStrength(pw) {
  if (!pw) return { score: 0, label: "", color: "transparent" };
  let s = 0;
  if (pw.length >= 8)            s++;
  if (/[A-Z]/.test(pw))         s++;
  if (/[0-9]/.test(pw))         s++;
  if (/[^a-zA-Z0-9]/.test(pw))  s++;
  return [
    { label: "Weak",   color: "#c4614a" },
    { label: "Fair",   color: "#c49454" },
    { label: "Good",   color: "#7a9bb5" },
    { label: "Strong", color: "#5a9e6f" },
    { label: "Strong", color: "#5a9e6f" },
  ][s] && { score: s, ...[
    { label: "Weak",   color: "#c4614a" },
    { label: "Fair",   color: "#c49454" },
    { label: "Good",   color: "#7a9bb5" },
    { label: "Strong", color: "#5a9e6f" },
    { label: "Strong", color: "#5a9e6f" },
  ][s] };
}

function validate(mode, form) {
  const e = {};
  if (mode === "signup") {
    if (!form.firstName.trim()) e.firstName = "Required";
    if (!form.lastName.trim())  e.lastName  = "Required";
  }
  if (!form.email.trim())               e.email    = "Email is required";
  else if (!/\S+@\S+\.\S+/.test(form.email)) e.email = "Enter a valid email";
  if (!form.password)                   e.password = "Password is required";
  else if (form.password.length < 6)    e.password = "Minimum 6 characters";
  if (mode === "signup" && form.password && form.confirmPassword !== form.password)
    e.confirmPassword = "Passwords don't match";
  return e;
}

/* ── User Dropdown ── */
export function UserNav({ user, onLogout }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  return (
    <div className="user-nav" ref={ref}>
      <div className="user-avatar" onClick={() => setOpen(!open)} title={user.email}>
        {(user.firstName || user.email || "U").charAt(0).toUpperCase()}
      </div>
      {open && (
        <div className="user-dropdown">
          <div className="user-dropdown-header">
            <div className="user-dropdown-name">{user.firstName} {user.lastName}</div>
            <div className="user-dropdown-email">{user.email}</div>
          </div>
          <button className="user-dropdown-item">📄 My Resumes</button>
          <button className="user-dropdown-item">🌐 My Portfolio</button>
          <button className="user-dropdown-item">⚙ Account Settings</button>
          <div className="user-dropdown-divider" />
          <button className="user-dropdown-item danger" onClick={() => { setOpen(false); onLogout(); }}>
            ↩ Sign Out
          </button>
        </div>
      )}
    </div>
  );
}

/* ── Auth Modal ── */
export default function Auth({ mode: initMode = "signin", onClose, onSuccess }) {
  const [mode,    setMode]    = useState(initMode);
  const [loading, setLoading] = useState(false);
  const [done,    setDone]    = useState(false);
  const [showPw,  setShowPw]  = useState(false);
  const [errors,  setErrors]  = useState({});
  const [apiErr,  setApiErr]  = useState("");
  const [form,    setForm]    = useState({
    firstName: "", lastName: "", email: "", password: "", confirmPassword: "",
  });

  const strength = getStrength(form.password);
  const upd = (f, v) => { setForm(p => ({ ...p, [f]: v })); setErrors(e => ({ ...e, [f]: "" })); setApiErr(""); };

  const handleSubmit = async () => {
    const errs = validate(mode, form);
    if (Object.keys(errs).length) { setErrors(errs); return; }

    setLoading(true);
    setApiErr("");
    try {
      let data;
      if (mode === "signup") {
        data = await authAPI.signup({
          firstName: form.firstName, lastName: form.lastName,
          email: form.email, password: form.password,
        });
        setDone(true);
        setTimeout(() => onSuccess?.(data.user), 1500);
      } else {
        data = await authAPI.login({ email: form.email, password: form.password });
        onSuccess?.(data.user);
      }
    } catch (err) {
      setApiErr(err.message || "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleKey = (e) => { if (e.key === "Enter" && !loading) handleSubmit(); };

  if (done) return (
    <div className="auth-overlay" onClick={(e) => e.target === e.currentTarget && onClose?.()}>
      <div className="auth-modal">
        <button className="auth-close" onClick={onClose}>×</button>
        <div className="auth-success">
          <div className="auth-success-icon">✓</div>
          <div className="auth-success-title">Welcome to SkillFolio!</div>
          <p className="auth-success-sub">Account created. Setting up your workspace…</p>
        </div>
      </div>
    </div>
  );

  return (
    <div className="auth-overlay" onClick={(e) => e.target === e.currentTarget && onClose?.()}>
      <div className="auth-modal">
        <button className="auth-close" onClick={onClose}>×</button>

        <div className="auth-header">
          <div className="auth-logo-wrap">
            <div className="auth-logo-mark" style={{fontSize:11,letterSpacing:"-0.5px"}}>SF</div>
            <span className="auth-logo-text">SkillFolio</span>
          </div>
          <div className="auth-title">{mode === "signup" ? "Create your account" : "Welcome back"}</div>
          <div className="auth-subtitle">
            {mode === "signup"
              ? "Join 24,000+ professionals building standout resumes"
              : "Sign in to continue building your career profile"}
          </div>
        </div>

        <div className="auth-tabs">
          <button className={`auth-tab${mode === "signin" ? " active" : ""}`} onClick={() => { setMode("signin"); setErrors({}); setApiErr(""); }}>Sign In</button>
          <button className={`auth-tab${mode === "signup" ? " active" : ""}`} onClick={() => { setMode("signup"); setErrors({}); setApiErr(""); }}>Create Account</button>
        </div>

        <div className="auth-body">
          {/* API error banner */}
          {apiErr && (
            <div style={{ background:"rgba(196,97,74,.1)", border:"1px solid rgba(196,97,74,.3)", color:"#a0402e", padding:"10px 14px", fontSize:12, marginBottom:16 }}>
              ⚠ {apiErr}
            </div>
          )}

          {mode === "signup" && (
            <div className="auth-row">
              <div className="auth-field">
                <label className="auth-label">First Name</label>
                <input className={`auth-input${errors.firstName ? " error" : ""}`} value={form.firstName} onChange={e => upd("firstName", e.target.value)} onKeyDown={handleKey} placeholder="Alex"/>
                {errors.firstName && <div className="auth-error-msg">⚠ {errors.firstName}</div>}
              </div>
              <div className="auth-field">
                <label className="auth-label">Last Name</label>
                <input className={`auth-input${errors.lastName ? " error" : ""}`} value={form.lastName} onChange={e => upd("lastName", e.target.value)} onKeyDown={handleKey} placeholder="Chen"/>
                {errors.lastName && <div className="auth-error-msg">⚠ {errors.lastName}</div>}
              </div>
            </div>
          )}

          <div className="auth-field">
            <label className="auth-label">Email Address</label>
            <input className={`auth-input${errors.email ? " error" : ""}`} type="email" value={form.email} onChange={e => upd("email", e.target.value)} onKeyDown={handleKey} placeholder="you@example.com"/>
            {errors.email && <div className="auth-error-msg">⚠ {errors.email}</div>}
          </div>

          <div className="auth-field">
            <label className="auth-label">Password</label>
            <div className="auth-input-wrap">
              <input className={`auth-input${errors.password ? " error" : ""}`} type={showPw ? "text" : "password"} value={form.password} onChange={e => upd("password", e.target.value)} onKeyDown={handleKey} placeholder={mode === "signup" ? "Create a strong password…" : "Enter your password"} style={{ paddingRight: 40 }}/>
              <span className="auth-input-icon" onClick={() => setShowPw(!showPw)}>{showPw ? "🙈" : "👁"}</span>
            </div>
            {errors.password && <div className="auth-error-msg">⚠ {errors.password}</div>}
            {mode === "signup" && form.password && strength && (
              <div className="auth-strength">
                {[1,2,3,4].map(i => (
                  <div key={i} className="auth-strength-bar">
                    <div className="auth-strength-fill" style={{ width: strength.score >= i ? "100%" : "0%", background: strength.color }}/>
                  </div>
                ))}
                <span className="auth-strength-label" style={{ color: strength.color }}>{strength.label}</span>
              </div>
            )}
          </div>

          {mode === "signup" && (
            <div className="auth-field">
              <label className="auth-label">Confirm Password</label>
              <input className={`auth-input${errors.confirmPassword ? " error" : ""}`} type={showPw ? "text" : "password"} value={form.confirmPassword} onChange={e => upd("confirmPassword", e.target.value)} onKeyDown={handleKey} placeholder="Repeat your password"/>
              {errors.confirmPassword && <div className="auth-error-msg">⚠ {errors.confirmPassword}</div>}
            </div>
          )}

          {mode === "signin" && (
            <div className="auth-options">
              <label className="auth-remember"><input type="checkbox"/> Remember me</label>
              <button className="auth-forgot">Forgot password?</button>
            </div>
          )}

          <button className="auth-submit" onClick={handleSubmit} disabled={loading}>
            {loading ? <><div className="auth-submit-spinner"/>Processing…</> : mode === "signup" ? "Create Account →" : "Sign In →"}
          </button>

          <div className="auth-switch">
            {mode === "signin"
              ? <>Don't have an account? <button onClick={() => { setMode("signup"); setErrors({}); }}>Sign up free</button></>
              : <>Already have an account? <button onClick={() => { setMode("signin"); setErrors({}); }}>Sign in</button></>}
          </div>

          {mode === "signup" && (
            <div className="auth-terms">
              By creating an account you agree to our <a href="#">Terms</a> and <a href="#">Privacy Policy</a>.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}