// DataCollection.js — Module 2
import { useState, useEffect } from "react";
import "./DataCollection.css";

const SECTIONS = [
  { id:"personal",       label:"Personal Info",    icon:"👤" },
  { id:"summary",        label:"Summary",          icon:"📝" },
  { id:"experience",     label:"Experience",       icon:"💼" },
  { id:"education",      label:"Education",        icon:"🎓" },
  { id:"skills",         label:"Skills",           icon:"⚡" },
  { id:"projects",       label:"Projects",         icon:"🚀" },
  { id:"certifications", label:"Certifications",   icon:"🏅" },
  { id:"extras",         label:"Extras",           icon:"✦"  },
];

const SKILL_SUGGESTIONS = [
  "JavaScript","React","Python","Figma","SQL","Node.js",
  "TypeScript","Machine Learning","AWS","Docker","Git","UI/UX",
];

const uid = () => Math.random().toString(36).slice(2,9);

/* ── Sub-section forms ── */
function Personal({ d, set }) {
  const u = (k,v) => set({...d,[k]:v});
  return (
    <>
      <div className="form-row">
        <div className="form-group"><label className="form-label">First Name *</label>
          <input className="form-input" value={d.firstName||""} onChange={e=>u("firstName",e.target.value)} placeholder="Alexandra"/></div>
        <div className="form-group"><label className="form-label">Last Name *</label>
          <input className="form-input" value={d.lastName||""} onChange={e=>u("lastName",e.target.value)} placeholder="Chen"/></div>
      </div>
      <div className="form-group"><label className="form-label">Professional Title *</label>
        <input className="form-input" value={d.title||""} onChange={e=>u("title",e.target.value)} placeholder="Senior Product Designer"/></div>
      <div className="form-row">
        <div className="form-group"><label className="form-label">Email *</label>
          <input className="form-input" type="email" value={d.email||""} onChange={e=>u("email",e.target.value)} placeholder="alex@email.com"/></div>
        <div className="form-group"><label className="form-label">Phone</label>
          <input className="form-input" value={d.phone||""} onChange={e=>u("phone",e.target.value)} placeholder="+1 555 000 0000"/></div>
      </div>
      <div className="form-row">
        <div className="form-group"><label className="form-label">City</label>
          <input className="form-input" value={d.city||""} onChange={e=>u("city",e.target.value)} placeholder="San Francisco"/></div>
        <div className="form-group"><label className="form-label">State / Country</label>
          <input className="form-input" value={d.location||""} onChange={e=>u("location",e.target.value)} placeholder="CA, USA"/></div>
      </div>
      <div className="form-row">
        <div className="form-group"><label className="form-label">LinkedIn</label>
          <input className="form-input" value={d.linkedin||""} onChange={e=>u("linkedin",e.target.value)} placeholder="linkedin.com/in/yourname"/></div>
        <div className="form-group"><label className="form-label">Portfolio / Website</label>
          <input className="form-input" value={d.website||""} onChange={e=>u("website",e.target.value)} placeholder="yoursite.com"/></div>
      </div>
    </>
  );
}

function Summary({ d, set }) {
  return (
    <>
      <div className="form-group">
        <label className="form-label">Professional Summary *</label>
        <textarea className="form-input form-textarea" style={{minHeight:130}}
          value={d.summary||""} onChange={e=>set({...d,summary:e.target.value})}
          placeholder="Describe your background, key strengths, and career goals in 3–5 sentences..."/>
        <div className="form-hint">💡 Use the AI Chatbot module to enhance this with professional language.</div>
      </div>
      <div className="tips-box">
        <div className="tips-box-title">✦ Tips for a strong summary</div>
        <ul>
          <li>Start with years of experience and field</li>
          <li>Highlight 2–3 key skills or achievements</li>
          <li>End with what you're looking for</li>
          <li>Keep it to 50–80 words</li>
        </ul>
      </div>
    </>
  );
}

function Experience({ items, onAdd, onUpdate, onRemove }) {
  return (
    <>
      {items.map((exp,i)=>(
        <div key={exp.id} className="dc-card" style={{animationDelay:`${i*.07}s`}}>
          <div className="dc-card-head">
            <span className="dc-card-title">{exp.company||`Experience ${i+1}`}</span>
            <button className="dc-card-remove" onClick={()=>onRemove(exp.id)}>×</button>
          </div>
          <div className="form-row">
            <div className="form-group"><label className="form-label">Job Title *</label>
              <input className="form-input" value={exp.title||""} onChange={e=>onUpdate(exp.id,"title",e.target.value)} placeholder="Lead Designer"/></div>
            <div className="form-group"><label className="form-label">Company *</label>
              <input className="form-input" value={exp.company||""} onChange={e=>onUpdate(exp.id,"company",e.target.value)} placeholder="Figma Inc."/></div>
          </div>
          <div className="form-row-3">
            <div className="form-group"><label className="form-label">Start Date</label>
              <input className="form-input" type="month" value={exp.startDate||""} onChange={e=>onUpdate(exp.id,"startDate",e.target.value)}/></div>
            <div className="form-group"><label className="form-label">End Date</label>
              <input className="form-input" type="month" value={exp.endDate||""} onChange={e=>onUpdate(exp.id,"endDate",e.target.value)} disabled={!!exp.current}/></div>
            <div className="form-group" style={{display:"flex",alignItems:"flex-end",paddingBottom:2}}>
              <label className="current-toggle">
                <input type="checkbox" checked={!!exp.current} onChange={e=>onUpdate(exp.id,"current",e.target.checked)}/>
                Current role
              </label>
            </div>
          </div>
          <div className="form-group"><label className="form-label">Location</label>
            <input className="form-input" value={exp.location||""} onChange={e=>onUpdate(exp.id,"location",e.target.value)} placeholder="San Francisco, CA"/></div>
          <div className="form-group">
            <label className="form-label">Key Responsibilities & Achievements</label>
            <textarea className="form-input form-textarea"
              value={exp.description||""} onChange={e=>onUpdate(exp.id,"description",e.target.value)}
              placeholder={"• Led redesign of core product, increasing retention by 18%\n• Managed team of 4 designers across 3 squads"}/>
            <div className="form-hint">One bullet per line starting with •</div>
          </div>
        </div>
      ))}
      <button className="dc-add-btn" onClick={onAdd}>+ Add Experience</button>
    </>
  );
}

function Education({ items, onAdd, onUpdate, onRemove }) {
  return (
    <>
      {items.map((edu,i)=>(
        <div key={edu.id} className="dc-card" style={{animationDelay:`${i*.07}s`}}>
          <div className="dc-card-head">
            <span className="dc-card-title">{edu.school||`Education ${i+1}`}</span>
            <button className="dc-card-remove" onClick={()=>onRemove(edu.id)}>×</button>
          </div>
          <div className="form-row">
            <div className="form-group"><label className="form-label">Degree *</label>
              <input className="form-input" value={edu.degree||""} onChange={e=>onUpdate(edu.id,"degree",e.target.value)} placeholder="B.Des Interaction Design"/></div>
            <div className="form-group"><label className="form-label">School *</label>
              <input className="form-input" value={edu.school||""} onChange={e=>onUpdate(edu.id,"school",e.target.value)} placeholder="Rhode Island School of Design"/></div>
          </div>
          <div className="form-row">
            <div className="form-group"><label className="form-label">Graduation Year</label>
              <input className="form-input" value={edu.year||""} onChange={e=>onUpdate(edu.id,"year",e.target.value)} placeholder="2021"/></div>
            <div className="form-group"><label className="form-label">GPA (optional)</label>
              <input className="form-input" value={edu.gpa||""} onChange={e=>onUpdate(edu.id,"gpa",e.target.value)} placeholder="3.8 / 4.0"/></div>
          </div>
          <div className="form-group"><label className="form-label">Honors / Activities</label>
            <input className="form-input" value={edu.honors||""} onChange={e=>onUpdate(edu.id,"honors",e.target.value)} placeholder="Dean's List, Design Society President"/></div>
        </div>
      ))}
      <button className="dc-add-btn" onClick={onAdd}>+ Add Education</button>
    </>
  );
}

function Skills({ items, onAdd, onUpdate, onRemove }) {
  const [newSkill, setNewSkill] = useState("");
  const add = (name) => { if(!name.trim())return; onAdd(name.trim()); setNewSkill(""); };
  const LEVELS = ["Beginner","Intermediate","Advanced","Expert"];
  return (
    <>
      <div className="dc-card">
        <div style={{fontFamily:"'Jost',sans-serif",fontSize:10,fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:"rgba(27,58,92,.45)",marginBottom:12}}>Quick Add</div>
        <div style={{display:"flex",gap:8,marginBottom:12}}>
          <input className="form-input" value={newSkill} onChange={e=>setNewSkill(e.target.value)}
            onKeyDown={e=>e.key==="Enter"&&add(newSkill)} placeholder="Type a skill and press Enter..."
            style={{flex:1}}/>
          <button className="btn btn-navy btn-sm" onClick={()=>add(newSkill)}>Add</button>
        </div>
        <div style={{fontFamily:"'Jost',sans-serif",fontSize:9,letterSpacing:".12em",textTransform:"uppercase",color:"rgba(27,58,92,.38)",marginBottom:6}}>Suggestions:</div>
        <div className="skill-suggestions">
          {SKILL_SUGGESTIONS.filter(s=>!items.find(i=>i.name===s)).slice(0,10).map(s=>(
            <button key={s} className="skill-suggest-chip" onClick={()=>add(s)}>+ {s}</button>
          ))}
        </div>
      </div>
      {items.length>0 && (
        <div className="dc-card">
          <div style={{fontFamily:"'Jost',sans-serif",fontSize:10,fontWeight:700,letterSpacing:".1em",textTransform:"uppercase",color:"rgba(27,58,92,.45)",marginBottom:16}}>
            Your Skills ({items.length})
          </div>
          {items.map((skill,i)=>(
            <div key={skill.id} style={{display:"grid",gridTemplateColumns:"1fr auto 28px",gap:10,alignItems:"center",marginBottom:12,paddingBottom:12,borderBottom:i<items.length-1?"1px solid rgba(168,188,200,.12)":"none"}}>
              <input className="form-input" value={skill.name} onChange={e=>onUpdate(skill.id,"name",e.target.value)} style={{padding:"7px 11px",fontSize:12}}/>
              <div className="skill-levels">
                {LEVELS.map(lv=>(
                  <button key={lv}
                    className={`skill-lv-btn${skill.level===lv?" sel-"+lv.toLowerCase():""}`}
                    onClick={()=>onUpdate(skill.id,"level",lv)}>{lv}</button>
                ))}
              </div>
              <button onClick={()=>onRemove(skill.id)}
                style={{background:"none",border:"none",color:"rgba(27,58,92,.28)",fontSize:18,cursor:"pointer",transition:"color .2s",lineHeight:1}}
                onMouseEnter={e=>e.target.style.color="var(--danger)"}
                onMouseLeave={e=>e.target.style.color="rgba(27,58,92,.28)"}>×</button>
            </div>
          ))}
        </div>
      )}
    </>
  );
}

function Projects({ items, onAdd, onUpdate, onRemove }) {
  return (
    <>
      {items.map((p,i)=>(
        <div key={p.id} className="dc-card" style={{animationDelay:`${i*.07}s`}}>
          <div className="dc-card-head">
            <span className="dc-card-title">{p.name||`Project ${i+1}`}</span>
            <button className="dc-card-remove" onClick={()=>onRemove(p.id)}>×</button>
          </div>
          <div className="form-row">
            <div className="form-group"><label className="form-label">Project Name *</label>
              <input className="form-input" value={p.name||""} onChange={e=>onUpdate(p.id,"name",e.target.value)} placeholder="Bloom Brand Identity"/></div>
            <div className="form-group"><label className="form-label">Your Role</label>
              <input className="form-input" value={p.role||""} onChange={e=>onUpdate(p.id,"role",e.target.value)} placeholder="Lead Designer"/></div>
          </div>
          <div className="form-group"><label className="form-label">Description</label>
            <textarea className="form-input form-textarea" value={p.description||""} onChange={e=>onUpdate(p.id,"description",e.target.value)} placeholder="Describe the project, your contributions, and outcomes..."/></div>
          <div className="form-row">
            <div className="form-group"><label className="form-label">Tech / Tools</label>
              <input className="form-input" value={p.tech||""} onChange={e=>onUpdate(p.id,"tech",e.target.value)} placeholder="Figma, React, TypeScript"/></div>
            <div className="form-group"><label className="form-label">Project URL</label>
              <input className="form-input" value={p.url||""} onChange={e=>onUpdate(p.id,"url",e.target.value)} placeholder="github.com/user/project"/></div>
          </div>
        </div>
      ))}
      <button className="dc-add-btn" onClick={onAdd}>+ Add Project</button>
    </>
  );
}

function Certifications({ items, onAdd, onUpdate, onRemove }) {
  return (
    <>
      {items.map((c,i)=>(
        <div key={c.id} className="dc-card" style={{animationDelay:`${i*.07}s`}}>
          <div className="dc-card-head">
            <span className="dc-card-title">{c.name||`Certification ${i+1}`}</span>
            <button className="dc-card-remove" onClick={()=>onRemove(c.id)}>×</button>
          </div>
          <div className="form-row">
            <div className="form-group"><label className="form-label">Certification Name *</label>
              <input className="form-input" value={c.name||""} onChange={e=>onUpdate(c.id,"name",e.target.value)} placeholder="AWS Solutions Architect"/></div>
            <div className="form-group"><label className="form-label">Issuing Organization</label>
              <input className="form-input" value={c.issuer||""} onChange={e=>onUpdate(c.id,"issuer",e.target.value)} placeholder="Amazon Web Services"/></div>
          </div>
          <div className="form-row">
            <div className="form-group"><label className="form-label">Date Issued</label>
              <input className="form-input" type="month" value={c.date||""} onChange={e=>onUpdate(c.id,"date",e.target.value)}/></div>
            <div className="form-group"><label className="form-label">Credential ID</label>
              <input className="form-input" value={c.credentialId||""} onChange={e=>onUpdate(c.id,"credentialId",e.target.value)} placeholder="ABC-123456"/></div>
          </div>
        </div>
      ))}
      <button className="dc-add-btn" onClick={onAdd}>+ Add Certification</button>
    </>
  );
}

function Extras({ d, set }) {
  const u = (k,v) => set({...d,[k]:v});
  return (
    <div className="dc-card">
      <div className="form-group"><label className="form-label">Languages</label>
        <input className="form-input" value={d.languages||""} onChange={e=>u("languages",e.target.value)} placeholder="English (Native), Mandarin (Fluent)"/>
        <div className="form-hint">Separate with commas</div></div>
      <div className="form-group"><label className="form-label">Awards & Honors</label>
        <textarea className="form-input form-textarea" style={{minHeight:70}} value={d.awards||""} onChange={e=>u("awards",e.target.value)} placeholder="Dean's List 2020, Design Excellence Award 2022"/></div>
      <div className="form-group"><label className="form-label">Publications</label>
        <textarea className="form-input form-textarea" style={{minHeight:70}} value={d.publications||""} onChange={e=>u("publications",e.target.value)} placeholder="List any publications or articles..."/></div>
      <div className="form-group" style={{marginBottom:0}}><label className="form-label">Interests / Hobbies</label>
        <input className="form-input" value={d.interests||""} onChange={e=>u("interests",e.target.value)} placeholder="Photography, Hiking, Open Source"/></div>
    </div>
  );
}

/* ── Completion calculator ── */
function calcDone(data) {
  const checks = [
    data.personal?.firstName, data.personal?.lastName,
    data.personal?.title, data.personal?.email,
    data.summary?.summary,
    (data.experience?.length||0)>0,
    (data.education?.length||0)>0,
    (data.skills?.length||0)>=3,
  ];
  return Math.round(checks.filter(Boolean).length/checks.length*100);
}

function isDone(sec, data) {
  if(sec==="personal")       return !!(data.personal?.firstName&&data.personal?.email);
  if(sec==="summary")        return !!(data.summary?.summary);
  if(sec==="experience")     return (data.experience?.length||0)>0;
  if(sec==="education")      return (data.education?.length||0)>0;
  if(sec==="skills")         return (data.skills?.length||0)>=3;
  return false;
}

export default function DataCollection({ initialData, onDataChange }) {
  const [active, setActive] = useState("personal");
  const [data, setData]     = useState(initialData || {
    personal:{}, summary:{}, experience:[], education:[],
    skills:[], projects:[], certifications:[], extras:{},
  });


  // Sync state when backend data loads after login
  useEffect(() => {
    if (initialData && Object.keys(initialData).length > 0) {
      setData(initialData);
    }
  }, [initialData]);

  const save = (updated) => { setData(updated); onDataChange?.(updated); };
  const updArr = (sec,id,field,val) => save({...data,[sec]:data[sec].map(x=>x.id===id?{...x,[field]:val}:x)});
  const addArr = (sec,def={})       => save({...data,[sec]:[...(data[sec]||[]),{id:uid(),...def}]});
  const delArr = (sec,id)           => save({...data,[sec]:data[sec].filter(x=>x.id!==id)});

  const idx  = SECTIONS.findIndex(s=>s.id===active);
  const done = calcDone(data);

  const TITLES = {
    personal:"Personal Information", summary:"Professional Summary",
    experience:"Work Experience", education:"Education",
    skills:"Skills", projects:"Projects",
    certifications:"Certifications", extras:"Additional Info",
  };

  return (
    <div className="dc-page">
      {/* Sidebar */}
      <aside className="dc-sidebar">
        <div className="dc-sidebar-brand">Folio Builder</div>
        {SECTIONS.map(s=>(
          <button key={s.id} className={`dc-nav-item${active===s.id?" active":""}`} onClick={()=>setActive(s.id)}>
            <span className="dc-nav-icon">{s.icon}</span>
            {s.label}
            {isDone(s.id,data) && <span className="dc-nav-check">✓</span>}
          </button>
        ))}
        <div className="dc-sidebar-prog">
          <div className="dc-prog-label">Profile Complete</div>
          <div className="dc-prog-track"><div className="dc-prog-fill" style={{width:`${done}%`}}/></div>
          <div className="dc-prog-pct">{done}%</div>
        </div>
      </aside>

      {/* Main */}
      <main className="dc-main">
        <div className="dc-section-head">
          <div className="dc-section-icon">{SECTIONS.find(s=>s.id===active)?.icon}</div>
          <span className="sec-tag">{idx+1} of {SECTIONS.length}</span>
          <h2 className="sec-title">{TITLES[active]}</h2>
        </div>

        {active==="personal"       && <Personal d={data.personal} set={p=>save({...data,personal:p})}/>}
        {active==="summary"        && <Summary  d={data.summary}  set={p=>save({...data,summary:p})}/>}
        {active==="experience"     && <Experience items={data.experience}
          onAdd={()=>addArr("experience")}
          onUpdate={(id,f,v)=>updArr("experience",id,f,v)}
          onRemove={id=>delArr("experience",id)}/>}
        {active==="education"      && <Education items={data.education}
          onAdd={()=>addArr("education")}
          onUpdate={(id,f,v)=>updArr("education",id,f,v)}
          onRemove={id=>delArr("education",id)}/>}
        {active==="skills"         && <Skills items={data.skills}
          onAdd={name=>addArr("skills",{name,level:"Intermediate"})}
          onUpdate={(id,f,v)=>updArr("skills",id,f,v)}
          onRemove={id=>delArr("skills",id)}/>}
        {active==="projects"       && <Projects items={data.projects}
          onAdd={()=>addArr("projects")}
          onUpdate={(id,f,v)=>updArr("projects",id,f,v)}
          onRemove={id=>delArr("projects",id)}/>}
        {active==="certifications" && <Certifications items={data.certifications}
          onAdd={()=>addArr("certifications")}
          onUpdate={(id,f,v)=>updArr("certifications",id,f,v)}
          onRemove={id=>delArr("certifications",id)}/>}
        {active==="extras"         && <Extras d={data.extras} set={p=>save({...data,extras:p})}/>}

        <div className="dc-footer">
          <button className="btn btn-outline" disabled={idx===0}
            onClick={()=>setActive(SECTIONS[idx-1].id)}>← Previous</button>
          <span className="dc-footer-note">{done}% complete</span>
          <button className="btn btn-navy"
            onClick={()=>{ if(idx<SECTIONS.length-1) setActive(SECTIONS[idx+1].id); }}>
            {idx===SECTIONS.length-1 ? "Finish ✓" : "Next →"}
          </button>
        </div>
      </main>
    </div>
  );
}