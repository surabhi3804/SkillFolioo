// src/api.js — All API calls from React to backend
// ─────────────────────────────────────────────────────

const BASE = "http://localhost:5000/api";

// ── Helper: attach JWT from localStorage ──
const authHeaders = () => {
  const token = localStorage.getItem("folio_token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

// ── Generic fetch wrapper ──
const req = async (method, path, body) => {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: authHeaders(),
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await res.json();
  if (!data.success) throw new Error(data.message || "Request failed");
  return data;
};

// ── ATS-specific fetch (no auth header needed) ──
const atsReq = async (method, path, body) => {
  const res = await fetch(`${BASE}${path}`, {
    method,
    headers: { "Content-Type": "application/json" },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "ATS request failed");
  return data;
};

// ─────────────────────────────────────────────────────
// AUTH
// ─────────────────────────────────────────────────────
export const authAPI = {

  signup: async ({ firstName, lastName, email, password }) => {
    const data = await req("POST", "/auth/signup", { firstName, lastName, email, password });
    localStorage.setItem("folio_token", data.token);
    localStorage.setItem("folio_user",  JSON.stringify(data.user));
    return data;
  },

  login: async ({ email, password }) => {
    const data = await req("POST", "/auth/login", { email, password });
    localStorage.setItem("folio_token", data.token);
    localStorage.setItem("folio_user",  JSON.stringify(data.user));
    return data;
  },

  getMe:           ()     => req("GET", "/auth/me"),
  updateProfile:   (body) => req("PUT", "/auth/profile", body),
  changePassword:  (body) => req("PUT", "/auth/change-password", body),

  logout: () => {
    localStorage.removeItem("folio_token");
    localStorage.removeItem("folio_user");
  },

  getStoredUser: () => {
    try {
      const u = localStorage.getItem("folio_user");
      return u ? JSON.parse(u) : null;
    } catch { return null; }
  },

  isLoggedIn: () => !!localStorage.getItem("folio_token"),
};

// ─────────────────────────────────────────────────────
// RESUME
// ─────────────────────────────────────────────────────
export const resumeAPI = {
  get:         ()                    => req("GET",    "/resume"),
  getAll:      ()                    => req("GET",    "/resume/all"),
  create:      (title="New Resume")  => req("POST",   "/resume", { title }),
  save:        (id, resumeData)      => req("PUT",    `/resume/${id}`, resumeData),
  saveSection: (id, section, data)   => req("PUT",    `/resume/${id}/section`, { section, data }),
  delete:      (id)                  => req("DELETE", `/resume/${id}`),
};

// ─────────────────────────────────────────────────────
// ATS SCORE
// ─────────────────────────────────────────────────────
export const atsAPI = {

  // Get all supported target roles → string[]
  getRoles: () =>
    atsReq("GET", "/ats/roles").then(d => d.roles),

  // Get keyword list for a role → string[]
  getKeywords: (role) =>
    atsReq("GET", `/ats/keywords/${encodeURIComponent(role)}`).then(d => d.keywords),

  // Evaluate resume vs role → result { overall, grade, breakdowns, actionItems, ... }
  evaluate: (resumeData, role) =>
    atsReq("POST", "/ats/evaluate", { resumeData, role }).then(d => d.result),

  // Evaluate with job description → result + jdHint + jdMatchedKeywords
  evaluateWithJD: (resumeData, role, jobDescription) =>
    atsReq("POST", "/ats/evaluate-with-jd", { resumeData, role, jobDescription }).then(d => d.result),
};