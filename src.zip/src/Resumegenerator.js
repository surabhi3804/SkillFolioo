// Resumegenerator.js — Module 6: Resume & Portfolio Generator
import React, { useState, useRef } from "react";
import "./Resumegenerator.css";

const PALETTES = [
  {id:"naval",   primary:"#1B3A5C", accent:"#7A9BB5", label:"Naval"},
  {id:"blush",   primary:"#C4948E", accent:"#1B3A5C", label:"Blush"},
  {id:"sage",    primary:"#4a7a4a", accent:"#A8BCC8", label:"Sage"},
  {id:"coastal", primary:"#7A9BB5", accent:"#C4B09A", label:"Coastal"},
  {id:"mauve",   primary:"#A87C7C", accent:"#E8D5CF", label:"Mauve"},
  {id:"slate",   primary:"#2d2d2d", accent:"#C4948E", label:"Slate"},
];

const FONTS = [
  {id:"cormorant", display:"Cormorant Garamond", body:"Jost",      label:"Editorial",  preview:"Elegant & Refined"},
  {id:"playfair",  display:"Playfair Display",   body:"Lato",      label:"Classic",    preview:"Balanced & Timeless"},
  {id:"montserrat",display:"Montserrat",         body:"Open Sans", label:"Modern",     preview:"Clean & Contemporary"},
];

const TEMPLATES = [
  {id:"executive",name:"Executive",layout:"two-col"},
  {id:"coastal",  name:"Coastal",  layout:"sidebar"},
  {id:"minimal",  name:"Minimal",  layout:"single"},
];

const LEVEL_PCT = {Expert:95,Advanced:80,Intermediate:54,Beginner:24};

/* ── Live Resume Paper ── */
const ResumePaper = React.forwardRef(function ResumePaper({ data, palette, font, templateId }, ref) {
  const p = palette || PALETTES[0];
  const f = font    || FONTS[0];
  const d = data    || {};
  const personal   = d.personal    || {};
  const summary    = d.summary     || {};
  const experience = d.experience  || [];
  const education  = d.education   || [];
  const skills     = d.skills      || [];
  const projects   = d.projects    || [];
  const certs      = d.certifications || [];

  const name = [personal.firstName, personal.lastName].filter(Boolean).join(" ") || "Your Name";
  const title= personal.title   || "Professional Title";
  const email= personal.email   || "email@example.com";
  const phone= personal.phone   || "";
  const city = personal.city    || "";
  const sumText = summary.summary || "Your professional summary will appear here. Use the Data Collection module to add it.";

  const headBg  = { background: p.primary };
  const secTitle = { fontSize:8, fontWeight:700, letterSpacing:".2em", textTransform:"uppercase", color:p.primary, marginBottom:8, paddingBottom:4, borderBottom:`1px solid ${p.accent}44` };
  const eTitle   = { fontSize:11, fontWeight:700, color:"#1B3A5C" };
  const eSub     = { fontSize:10, fontStyle:"italic", color:p.accent, marginTop:1 };
  const bodyTxt  = { fontSize:10, color:"rgba(27,58,92,.68)", lineHeight:1.78, fontFamily:f.body+",sans-serif" };

  if(templateId==="coastal") return (
    <div ref={ref} className="resume-paper tpl-coastal" style={{fontFamily:f.body+",sans-serif"}}>
      <div className="rp-head" style={{...headBg, padding:"22px 28px 16px", display:"flex", gap:14, alignItems:"center"}}>
        <div style={{width:48,height:48,borderRadius:"50%",background:p.accent,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,color:"#fff",flexShrink:0,fontFamily:f.display+",serif"}}>{name.charAt(0)}</div>
        <div>
          <div className="rp-name" style={{fontFamily:f.display+",serif",fontSize:24,fontWeight:600,color:"#fff"}}>{name}</div>
          <div className="rp-role" style={{fontSize:10,letterSpacing:".12em",color:"rgba(255,255,255,.6)",marginTop:3}}>{title}</div>
        </div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"162px 1fr"}}>
        <div className="rp-left" style={{background:`${p.primary}0a`}}>
          <div className="rp-sec">
            <div className="rp-sec-title" style={secTitle}>Contact</div>
            <div style={bodyTxt}>{email}</div>
            {phone && <div style={bodyTxt}>{phone}</div>}
            {city  && <div style={bodyTxt}>{city}</div>}
          </div>
          {skills.length>0 && (
            <div className="rp-sec">
              <div className="rp-sec-title" style={secTitle}>Skills</div>
              {skills.slice(0,8).map(s=>(
                <div key={s.id} className="rp-skill-row">
                  <div className="rp-skill-name" style={{...bodyTxt,width:56}}>{s.name}</div>
                  <div className="rp-skill-bar"><div className="rp-skill-fill" style={{width:`${LEVEL_PCT[s.level]||50}%`,background:`linear-gradient(90deg,${p.primary},${p.accent})`}}/></div>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="rp-right">
          {sumText && <div className="rp-sec"><div className="rp-sec-title" style={secTitle}>Profile</div><p style={bodyTxt}>{sumText}</p></div>}
          {experience.length>0 && (
            <div className="rp-sec">
              <div className="rp-sec-title" style={secTitle}>Experience</div>
              {experience.slice(0,3).map(exp=>(
                <div key={exp.id} className="rp-entry">
                  <div className="rp-entry-row"><span style={eTitle}>{exp.title}</span><span style={{fontSize:9,color:"rgba(27,58,92,.38)"}}>{exp.startDate?.slice(0,7)} – {exp.current?"Now":exp.endDate?.slice(0,7)}</span></div>
                  <div style={eSub}>{exp.company}{exp.location?` · ${exp.location}`:""}</div>
                  {exp.description && <p style={{...bodyTxt,marginTop:3}}>{exp.description.slice(0,100)}...</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div ref={ref} className="resume-paper tpl-executive" style={{fontFamily:f.body+",sans-serif"}}>
      <div className="rp-head" style={headBg}>
        <div className="rp-name" style={{fontFamily:f.display+",serif"}}>{name}</div>
        <div className="rp-role">{title}</div>
        <div className="rp-contacts">
          <span className="rp-contact-item">{email}</span>
          {phone && <span className="rp-contact-item">{phone}</span>}
          {city  && <span className="rp-contact-item">{city}</span>}
        </div>
      </div>
      <div className="rp-body">
        <div className="rp-left" style={{background:`${p.primary}07`}}>
          {skills.length>0 && (
            <div className="rp-sec">
              <div className="rp-sec-title" style={{...secTitle}}>{/* */}Skills</div>
              {skills.slice(0,8).map(s=>(
                <div key={s.id} className="rp-skill-row">
                  <div className="rp-skill-name" style={bodyTxt}>{s.name}</div>
                  <div className="rp-skill-bar"><div className="rp-skill-fill" style={{width:`${LEVEL_PCT[s.level]||50}%`,background:`linear-gradient(90deg,${p.primary},${p.accent})`}}/></div>
                </div>
              ))}
            </div>
          )}
          {education.length>0 && (
            <div className="rp-sec">
              <div className="rp-sec-title" style={secTitle}>Education</div>
              {education.map(edu=>(
                <div key={edu.id} className="rp-entry">
                  <div style={eTitle}>{edu.degree}</div>
                  <div style={eSub}>{edu.school}</div>
                  <div style={{...bodyTxt,color:"rgba(27,58,92,.38)"}}>{edu.year}</div>
                </div>
              ))}
            </div>
          )}
          {certs.length>0 && (
            <div className="rp-sec">
              <div className="rp-sec-title" style={secTitle}>Certifications</div>
              {certs.map(c=>(
                <div key={c.id} className="rp-entry">
                  <div style={eTitle}>{c.name}</div>
                  <div style={eSub}>{c.issuer}</div>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="rp-right">
          {sumText && <div className="rp-sec"><div className="rp-sec-title" style={{...secTitle,color:p.primary}}>Profile</div><p className="rp-body-txt">{sumText}</p></div>}
          {experience.length>0 && (
            <div className="rp-sec">
              <div className="rp-sec-title" style={{...secTitle,color:p.primary}}>Experience</div>
              {experience.slice(0,4).map(exp=>(
                <div key={exp.id} className="rp-entry">
                  <div className="rp-entry-row"><span style={eTitle}>{exp.title}</span><span className="rp-entry-date">{exp.startDate?.slice(0,7)} – {exp.current?"Present":exp.endDate?.slice(0,7)}</span></div>
                  <div style={{...eSub,color:p.accent}}>{exp.company}{exp.location?` · ${exp.location}`:""}</div>
                  {exp.description && (
                    <ul className="rp-entry-list">
                      {exp.description.split("\n").slice(0,3).filter(Boolean).map((b,i)=>(
                        <li key={i} style={{...bodyTxt,color:""}}>{b.replace(/^[•\-]\s*/,"")}</li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          )}
          {projects.length>0 && (
            <div className="rp-sec">
              <div className="rp-sec-title" style={{...secTitle,color:p.primary}}>Projects</div>
              {projects.slice(0,2).map(proj=>(
                <div key={proj.id} className="rp-entry">
                  <div className="rp-entry-row"><span style={eTitle}>{proj.name}</span>{proj.role&&<span style={eSub}>{proj.role}</span>}</div>
                  {proj.description&&<p style={{...bodyTxt,marginTop:3}}>{proj.description.slice(0,100)}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
});

/* ── Collapsible section ── */
function CtrlSection({icon, title, children, open:initOpen=true}) {
  const [open, setOpen] = useState(initOpen);
  return (
    <div className="gen-ctrl">
      <div className="gen-ctrl-head" onClick={()=>setOpen(!open)}>
        <span className="gen-ctrl-head-title"><span className="gen-ctrl-icon">{icon}</span>{title}</span>
        <span className={`gen-ctrl-arrow${open?" open":""}`}>▾</span>
      </div>
      {open && <div className="gen-ctrl-body">{children}</div>}
    </div>
  );
}

/* ── Main component ── */
export default function Resumegenerator({ resumeData, selectedTemplate }) {
  const printRef = useRef(null);  // ref for react-to-print
  const [palette,  setPalette]  = useState(PALETTES[0]);
  const [font,     setFont]     = useState(FONTS[0]);
  const [template, setTemplate] = useState(selectedTemplate || TEMPLATES[0]);
  const [zoom,     setZoom]     = useState(0.72);
  const [copied,   setCopied]   = useState(false);
  const [toast,    setToast]    = useState(null);

  function showToast(msg, type="success") {
    setToast({msg,type});
    setTimeout(()=>setToast(null),2800);
  }

  // PDF export using html2canvas + jsPDF — direct download, no print dialog
  async function handleExportPDF() {
    const el = printRef.current;
    if (!el) { showToast("No resume to export!"); return; }
    showToast("Generating PDF...");

    try {
      // Dynamically load libraries
      const html2canvas = (await import("html2canvas")).default;
      const { jsPDF }   = await import("jspdf");

      // Capture the resume element as a canvas
      const canvas = await html2canvas(el, {
        scale: 2,
        useCORS: true,
        backgroundColor: "#ffffff",
        logging: false,
        width: el.scrollWidth,
        height: el.scrollHeight,
      });

      const imgData = canvas.toDataURL("image/png");

      // A4 dimensions in mm
      const pdf     = new jsPDF({ orientation:"portrait", unit:"mm", format:"a4" });
      const pdfW    = pdf.internal.pageSize.getWidth();
      const pdfH    = pdf.internal.pageSize.getHeight();

      // Scale image to fit A4
      const imgW    = canvas.width;
      const imgH    = canvas.height;
      const ratio   = Math.min(pdfW / imgW * 3.7795, pdfH / imgH * 3.7795);
      const finalW  = imgW * ratio / 3.7795;
      const finalH  = imgH * ratio / 3.7795;

      pdf.addImage(imgData, "PNG", 0, 0, finalW, finalH);
      pdf.save("resume.pdf");
      showToast("✓ PDF downloaded!");
    } catch (err) {
      console.error("PDF error:", err);
      showToast("PDF failed — check console");
    }
  }

  function copyLink() {
    const link = `folio.so/${(resumeData?.personal?.firstName||"yourname").toLowerCase()}`;
    navigator.clipboard.writeText(link).then(()=>{ setCopied(true); showToast("Portfolio link copied!"); setTimeout(()=>setCopied(false),2000); });
  }

  const shareUrl = `folio.so/${(resumeData?.personal?.firstName||"yourname").toLowerCase()}`;

  const checklist = [
    ["Personal info",   !!(resumeData?.personal?.firstName)],
    ["Summary",         !!(resumeData?.summary?.summary)],
    ["Experience",      (resumeData?.experience?.length||0)>0],
    ["Education",       (resumeData?.education?.length||0)>0],
    ["Skills (5+)",     (resumeData?.skills?.length||0)>=5],
    ["Projects",        (resumeData?.projects?.length||0)>0],
    ["ATS Score 70+",   false],
  ];

  return (
    <div className="gen-page fade-up">
      <div className="gen-head">
        <span className="sec-tag">Module 6</span>
        <h2 className="sec-title">Resume <em>&amp; Portfolio</em> Generator</h2>
        <p className="sec-sub">Live preview, color &amp; font customization, PDF export and web portfolio publishing.</p>
      </div>

      <div className="gen-type-tabs tabs">
        {["PDF Resume","Web Portfolio"].map((t,i)=>(
          <button key={t} className={`tab-btn${i===0?" active":""}`}>{t}</button>
        ))}
      </div>

      <div className="gen-layout">
        {/* Preview */}
        <div className="gen-preview-area">
          <div className="gen-zoom-bar">
            <span className="gen-zoom-label">Live Preview</span>
            <button className="gen-zoom-btn" onClick={()=>setZoom(z=>Math.max(.4,z-.08))}>−</button>
            <span className="gen-zoom-pct">{Math.round(zoom*100)}%</span>
            <button className="gen-zoom-btn" onClick={()=>setZoom(z=>Math.min(1.1,z+.08))}>+</button>
            <button className="gen-zoom-btn" style={{fontSize:11}} onClick={()=>setZoom(.72)} title="Reset">⊡</button>
          </div>
          <div className="gen-paper-wrap">
            <div style={{transform:`scale(${zoom})`,transformOrigin:"top center"}}>
              <ResumePaper
                data={resumeData}
                palette={palette}
                font={font}
                templateId={template.id}
              />
            </div>
          </div>

          {/* Print-only version — full size, positioned off screen so html2canvas can capture it */}
          <div id="print-only-resume" style={{position:"fixed",top:0,left:"-9999px",width:"210mm",zIndex:-1,pointerEvents:"none",background:"#fff"}}>
            <ResumePaper
              ref={printRef}
              data={resumeData}
              palette={palette}
              font={font}
              templateId={template.id}
            />
          </div>
        </div>

        {/* Controls */}
        <div className="gen-controls">
          {/* Template */}
          <CtrlSection icon="▣" title="Template Layout">
            <div className="gen-tpl-thumbs">
              {TEMPLATES.map(tpl=>(
                <div key={tpl.id} className={`gen-tpl-thumb${template.id===tpl.id?" active":""}`} onClick={()=>setTemplate(tpl)}>
                  <div className="gen-tpl-thumb-inner" style={{background:`linear-gradient(135deg,${palette.primary}12,${palette.accent}1a)`,padding:8}}>
                    {tpl.layout==="two-col"&&<div style={{display:"flex",height:"100%",gap:4}}>
                      <div style={{width:"35%",background:`${palette.primary}10`}}/>
                      <div style={{flex:1,display:"flex",flexDirection:"column",gap:3,paddingTop:4}}>
                        {[100,80,90].map((w,i)=><div key={i} style={{height:3,background:`${palette.primary}20`,width:`${w}%`,borderRadius:1}}/>)}
                      </div>
                    </div>}
                    {tpl.layout==="sidebar"&&<div style={{padding:4}}>
                      <div style={{height:12,background:palette.primary,marginBottom:6}}/>
                      {[100,80,90].map((w,i)=><div key={i} style={{height:2,background:`${palette.primary}18`,width:`${w}%`,marginBottom:3,borderRadius:1}}/>)}
                    </div>}
                    {tpl.layout==="single"&&<div style={{padding:4}}>
                      <div style={{height:10,background:palette.primary,marginBottom:6}}/>
                      {[100,85,92,78].map((w,i)=><div key={i} style={{height:2,background:`${palette.primary}18`,width:`${w}%`,marginBottom:3,borderRadius:1}}/>)}
                    </div>}
                  </div>
                  <div className="gen-tpl-thumb-name">{tpl.name}</div>
                </div>
              ))}
            </div>
          </CtrlSection>

          {/* Colors */}
          <CtrlSection icon="◈" title="Color Palette">
            <div className="gen-swatches">
              {PALETTES.map(pal=>(
                <div key={pal.id} className={`gen-swatch${palette.id===pal.id?" active":""}`}
                  style={{background:pal.primary}} title={pal.label} onClick={()=>setPalette(pal)}/>
              ))}
            </div>
          </CtrlSection>

          {/* Fonts */}
          <CtrlSection icon="✦" title="Font Pairing">
            <div className="gen-fonts">
              {FONTS.map(f=>(
                <div key={f.id} className={`gen-font-opt${font.id===f.id?" active":""}`} onClick={()=>setFont(f)}>
                  <div>
                    <div className="gen-font-name" style={{fontFamily:f.display+",serif"}}>{f.display}</div>
                    <div className="gen-font-preview">{f.preview}</div>
                  </div>
                  {font.id===f.id && <span style={{color:"var(--blush)",fontSize:16}}>✓</span>}
                </div>
              ))}
            </div>
          </CtrlSection>

          {/* Export */}
          <div className="gen-export">
            <div className="gen-export-title">Export &amp; Publish</div>
            <div className="gen-export-btns">
              <button className="gen-export-btn pdf" onClick={handleExportPDF}>
                <span className="gen-export-btn-icon">📄</span>
                <span className="gen-export-btn-label">Download PDF</span>
                <span className="gen-export-btn-arrow">↓</span>
              </button>
              <button className="gen-export-btn docx">
                <span className="gen-export-btn-icon">📝</span>
                <span className="gen-export-btn-label">Export as DOCX</span>
                <span className="gen-export-btn-arrow">↓</span>
              </button>
              <button className="gen-export-btn link">
                <span className="gen-export-btn-icon">🌐</span>
                <span className="gen-export-btn-label">Publish Portfolio</span>
                <span className="gen-export-btn-arrow">↗</span>
              </button>
            </div>
            <div className="gen-share">
              <div className="gen-share-label">Your Portfolio URL</div>
              <div className="gen-share-row">
                <input className="gen-share-input" value={shareUrl} readOnly/>
                <button className="gen-copy-btn" onClick={copyLink}>{copied?"✓":"Copy"}</button>
              </div>
            </div>
          </div>

          {/* Checklist */}
          <CtrlSection icon="✔" title="Completion Checklist" open={false}>
            {checklist.map(([label,done])=>(
              <div key={label} className="gen-check-item">
                <span className={done?"gen-check-icon-done":"gen-check-icon-pending"}>{done?"✓":"○"}</span>
                <span style={{color:done?"var(--naval)":"rgba(27,58,92,.4)"}}>{label}</span>
              </div>
            ))}
          </CtrlSection>
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div className={`toast${toast.type==="success"?" success":""}`}>
          <span>{toast.type==="success"?"✓":"!"}</span>
          {toast.msg}
        </div>
      )}
    </div>
  );
}