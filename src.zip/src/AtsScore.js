// AtsScore.js — Module 5: ATS Score Evaluation
import { useState, useMemo } from "react";
import "./AtsScore.css";

const ROLE_KEYWORDS = {
  "Software Engineer":  ["python","javascript","react","node","sql","git","api","agile","backend","frontend","ci/cd","testing","microservices"],
  "Product Designer":   ["figma","ux","ui","prototyping","user research","design system","wireframe","usability","accessibility","interaction"],
  "Data Scientist":     ["python","machine learning","sql","pandas","numpy","statistics","model","data analysis","visualization","tensorflow","scikit-learn"],
  "Product Manager":    ["roadmap","stakeholder","agile","scrum","metrics","kpis","user stories","prioritization","cross-functional","product strategy"],
  "Marketing Manager":  ["seo","content strategy","analytics","campaigns","roi","brand","digital marketing","social media","email marketing","a/b testing"],
  "DevOps Engineer":    ["aws","docker","kubernetes","ci/cd","terraform","linux","bash","jenkins","monitoring","cloud","infrastructure","ansible"],
};

const ACTION_VERBS = ["led","managed","built","developed","designed","implemented","increased","reduced","launched","created","optimized","delivered","achieved","spearheaded","engineered","drove","streamlined"];

const STRUCTURE = [
  {id:"name",       label:"Full Name",              weight:8},
  {id:"contact",    label:"Contact Info",           weight:10},
  {id:"summary",    label:"Professional Summary",   weight:12},
  {id:"experience", label:"Work Experience",        weight:20},
  {id:"education",  label:"Education",              weight:14},
  {id:"skills",     label:"Skills Section",         weight:16},
  {id:"dates",      label:"Employment Dates",       weight:8},
  {id:"bullets",    label:"Bullet Points",          weight:7},
  {id:"length",     label:"Appropriate Length",     weight:5},
];

function grade(score) {
  if(score>=85) return {label:"Excellent",cls:"excellent",color:"var(--success)"};
  if(score>=70) return {label:"Good",     cls:"good",     color:"var(--windy)"};
  if(score>=55) return {label:"Fair",     cls:"fair",     color:"var(--warning)"};
  return              {label:"Needs Work",cls:"poor",     color:"var(--danger)"};
}

function evaluate(data, role) {
  if(!data) return null;
  const allText = [
    data.personal?.firstName, data.personal?.lastName,
    data.summary?.summary,
    ...(data.experience||[]).map(e=>`${e.title} ${e.company} ${e.description}`),
    ...(data.skills||[]).map(s=>s.name),
    ...(data.projects||[]).map(p=>`${p.name} ${p.description}`),
  ].filter(Boolean).join(" ").toLowerCase();

  const roleKws = ROLE_KEYWORDS[role]||ROLE_KEYWORDS["Software Engineer"];
  const found   = roleKws.filter(k=>allText.includes(k));
  const missing = roleKws.filter(k=>!allText.includes(k));
  const kwScore = Math.round(found.length/roleKws.length*100);

  const strChecks = STRUCTURE.map(c=>{
    let pass = false;
    switch(c.id){
      case "name":       pass=!!(data.personal?.firstName&&data.personal?.lastName); break;
      case "contact":    pass=!!(data.personal?.email); break;
      case "summary":    pass=!!(data.summary?.summary&&data.summary.summary.length>50); break;
      case "experience": pass=(data.experience?.length||0)>0; break;
      case "education":  pass=(data.education?.length||0)>0; break;
      case "skills":     pass=(data.skills?.length||0)>=3; break;
      case "dates":      pass=(data.experience||[]).every(e=>e.startDate); break;
      case "bullets":    pass=(data.experience||[]).some(e=>e.description?.includes("•")||e.description?.includes("-")); break;
      case "length":     pass=(data.experience?.length||0)<=5; break;
    }
    return {...c,pass};
  });
  const total = strChecks.reduce((s,c)=>s+c.weight,0);
  const strScore = Math.round(strChecks.filter(c=>c.pass).reduce((s,c)=>s+c.weight,0)/total*100);

  const expText = (data.experience||[]).map(e=>e.description||"").join(" ").toLowerCase();
  const verbsFound = ACTION_VERBS.filter(v=>expText.includes(v));
  const numsFound  = (expText.match(/\d+/g)||[]).length;
  const noPronouns = !["i ","me ","my ","we ","our "].some(p=>expText.includes(p));

  const clarityScore = Math.round(
    (Math.min(verbsFound.length/5,1)*30) +
    (Math.min(numsFound/6,1)*35) +
    (noPronouns?20:0) +
    (expText.length>100?15:0)
  );

  const skills = (data.skills||[]).map(s=>s.name.toLowerCase());
  const domMatch = roleKws.filter(k=>skills.some(s=>s.includes(k)||k.includes(s))).length;
  const domScore = Math.round(domMatch/Math.min(roleKws.length,8)*100);

  const compFields = [
    data.personal?.firstName, data.personal?.email, data.personal?.phone,
    data.summary?.summary, (data.experience?.length||0)>0,
    (data.education?.length||0)>0, (data.skills?.length||0)>=5,
    (data.projects?.length||0)>0,
  ];
  const compScore = Math.round(compFields.filter(Boolean).length/compFields.length*100);

  const overall = Math.round(kwScore*.25+strScore*.25+clarityScore*.2+domScore*.15+compScore*.15);
  return { overall, kwScore, strScore, clarityScore, domScore, compScore, found, missing, strChecks, verbsFound, numsFound, noPronouns };
}

/* ── Score Ring ── */
function Ring({ score, color }) {
  const size=130, sw=10, r=(size-sw)/2;
  const circ = 2*Math.PI*r;
  const offset = circ - (score/100)*circ;
  return (
    <div style={{position:"relative",display:"inline-flex",alignItems:"center",justifyContent:"center"}}>
      <svg width={size} height={size} className="ats-ring-svg">
        <circle className="ats-ring-track" cx={size/2} cy={size/2} r={r} strokeWidth={sw}/>
        <circle className="ats-ring-fill" cx={size/2} cy={size/2} r={r}
          strokeWidth={sw} stroke={color}
          strokeDasharray={circ} strokeDashoffset={offset}
          transform={`rotate(-90 ${size/2} ${size/2})`}/>
      </svg>
      <div style={{position:"absolute",textAlign:"center"}}>
        <div className="ats-score-num">{score}</div>
        <div className="ats-score-denom">/ 100</div>
      </div>
    </div>
  );
}

/* ── Demo data ── */
const DEMO = {
  personal:{firstName:"Alexandra",lastName:"Chen",email:"alex@email.com",phone:"+1 555 0000"},
  summary:{summary:"Senior product designer with 5+ years building digital products. Led cross-functional teams and increased user retention by 18%. Passionate about design systems and accessibility."},
  experience:[{id:"1",title:"Lead Designer",company:"Figma",startDate:"2022-01",description:"• Led redesign of core editor, increasing retention by 18%\n• Built component library from 800 to 1200 components"}],
  education:[{id:"1",degree:"B.Des",school:"RISD",year:"2020"}],
  skills:[{id:"1",name:"Figma",level:"Expert"},{id:"2",name:"UX",level:"Expert"},{id:"3",name:"Prototyping",level:"Advanced"},{id:"4",name:"User Research",level:"Advanced"},{id:"5",name:"Design System",level:"Advanced"}],
  projects:[{id:"1",name:"Portfolio Redesign",description:"Full redesign using Figma and React"}],
};

export default function AtsScore({ resumeData }) {
  const [role, setRole]     = useState("Product Designer");
  const [showJD, setShowJD] = useState(false);

  const data = resumeData || DEMO;
  const R    = useMemo(()=>evaluate(data,role),[data,role]);

  if(!R) return null;
  const g = grade(R.overall);

  const breakdowns = [
    {label:"Keyword Match",    score:R.kwScore,      color:"var(--naval)"},
    {label:"Document Structure",score:R.strScore,   color:"var(--windy)"},
    {label:"Writing Clarity",  score:R.clarityScore, color:"var(--blush)"},
    {label:"Skill-Domain Fit", score:R.domScore,     color:"var(--linwood)"},
    {label:"Completeness",     score:R.compScore,    color:"var(--upward)"},
  ];

  function ckClass(s) { return s>=70?"pass":s>=45?"warn":"fail"; }
  function ckIcon(s)  { return s>=70?"✓":s>=45?"⚠":"✗"; }

  return (
    <div className="ats-page fade-up">
      <div className="ats-head">
        <span className="sec-tag">Module 5</span>
        <h2 className="sec-title">ATS Score <em>Evaluation</em></h2>
        <p className="sec-sub">Rule-based scoring across keywords, structure, clarity, domain fit, and completeness.</p>
      </div>

      {/* Controls */}
      <div className="ats-controls">
        <span className="ats-role-label">Target Role:</span>
        <select className="ats-role-select" value={role} onChange={e=>setRole(e.target.value)}>
          {Object.keys(ROLE_KEYWORDS).map(r=><option key={r}>{r}</option>)}
        </select>
        <button className="btn btn-outline btn-sm" onClick={()=>setShowJD(!showJD)}>
          {showJD?"Hide JD":"Paste Job Description"}
        </button>
      </div>
      {showJD && (
        <div className="ats-jd-wrap">
          <textarea className="form-input form-textarea" placeholder="Paste the job description here for more accurate keyword matching..." style={{minHeight:90}}/>
          <div className="form-hint">Keywords from the job description will improve scoring accuracy.</div>
        </div>
      )}

      {/* Main layout */}
      <div className="ats-layout">
        {/* Ring panel */}
        <div className="ats-ring-panel">
          <Ring score={R.overall} color={g.color}/>
          <div className={`ats-grade ${g.cls}`}>{g.label}</div>
          <div className="ats-role-tag">for {role}</div>
          <div className="ats-breakdown">
            {breakdowns.map(b=>(
              <div key={b.label} className="ats-bd-item">
                <div className="ats-bd-row">
                  <span className="ats-bd-name">{b.label}</span>
                  <span className="ats-bd-score" style={{color:b.color}}>{b.score}</span>
                </div>
                <div className="prog-track">
                  <div className="prog-fill" style={{width:`${b.score}%`,background:b.color}}/>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Checks */}
        <div className="ats-checks">
          {/* Keywords */}
          <div className="ats-check-card">
            <div className={`ats-check-icon ${ckClass(R.kwScore)}`}>{ckIcon(R.kwScore)}</div>
            <div style={{flex:1}}>
              <div className="ats-check-title">Keyword Relevance</div>
              <div className="ats-check-detail">Found {R.found.length} of {R.found.length+R.missing.length} target keywords for {role}.</div>
              <div className="ats-kw-section">
                <div className="ats-kw-title found">Found ({R.found.length})</div>
                <div className="ats-kw-grid">{R.found.map(k=><span key={k} className="ats-kw-pill found">✓ {k}</span>)}</div>
                {R.missing.length>0 && <>
                  <div className="ats-kw-title missing">Missing ({R.missing.length})</div>
                  <div className="ats-kw-grid">{R.missing.map(k=><span key={k} className="ats-kw-pill missing">✗ {k}</span>)}</div>
                </>}
              </div>
            </div>
            <div className={`ats-check-score ${ckClass(R.kwScore)}`}>{R.kwScore}</div>
          </div>

          {/* Structure */}
          <div className="ats-check-card">
            <div className={`ats-check-icon ${ckClass(R.strScore)}`}>{ckIcon(R.strScore)}</div>
            <div style={{flex:1}}>
              <div className="ats-check-title">Document Structure</div>
              <div className="ats-check-detail">Checks for essential resume sections and formatting standards.</div>
              <div className="ats-struct-grid">
                {R.strChecks.map(c=>(
                  <div key={c.id} className="ats-struct-item">
                    <span style={{color:c.pass?"var(--success)":"var(--danger)",fontSize:13}}>{c.pass?"✓":"✗"}</span>
                    {c.label}
                  </div>
                ))}
              </div>
            </div>
            <div className={`ats-check-score ${ckClass(R.strScore)}`}>{R.strScore}</div>
          </div>

          {/* Clarity */}
          <div className="ats-check-card">
            <div className={`ats-check-icon ${ckClass(R.clarityScore)}`}>{ckIcon(R.clarityScore)}</div>
            <div style={{flex:1}}>
              <div className="ats-check-title">Writing Clarity</div>
              <div className="ats-check-detail">Checks for action verbs, quantified achievements, and professional tone.</div>
              <div className="ats-struct-grid" style={{marginTop:10}}>
                {[
                  [R.verbsFound.length>=3,"Action Verbs ("+R.verbsFound.length+" found)"],
                  [R.numsFound>=2,"Quantified Metrics ("+R.numsFound+" found)"],
                  [R.noPronouns,"No Personal Pronouns"],
                  [true,"Consistent Formatting"],
                ].map(([p,l],i)=>(
                  <div key={i} className="ats-struct-item">
                    <span style={{color:p?"var(--success)":"var(--danger)",fontSize:13}}>{p?"✓":"✗"}</span>
                    {l}
                  </div>
                ))}
              </div>
            </div>
            <div className={`ats-check-score ${ckClass(R.clarityScore)}`}>{R.clarityScore}</div>
          </div>

          {/* Action items */}
          {R.overall<85 && (
            <div className="ats-actions-card">
              <div className="ats-actions-title">🎯 Action Items to reach 85+</div>
              <ul className="ats-actions-list">
                {R.missing.length>0 && <li>Add these missing keywords: <strong>{R.missing.slice(0,3).join(", ")}</strong></li>}
                {!R.strChecks.find(c=>c.id==="summary")?.pass && <li>Write a professional summary (50–80 words)</li>}
                {R.numsFound<2 && <li>Add at least 2 quantifiable achievements with numbers</li>}
                {R.verbsFound.length<3 && <li>Start bullet points with strong action verbs</li>}
                {R.compScore<80 && <li>Fill in missing profile sections to improve completeness</li>}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}