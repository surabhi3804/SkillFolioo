import React, { useState, useEffect } from 'react';
import './LandingPage.css';

export default function LandingPage({ onSignIn, onGetStarted }) {

  /* ── scroll reveal ── */
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: 0.12 }
    );
    document.querySelectorAll('.reveal, .reveal-left, .reveal-right').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  const features = [
    { icon: '🤖', title: 'AI-Powered Assistant',      desc: 'Get real-time suggestions, professional rephrasing, and intelligent content recommendations as you build your resume.' },
    { icon: '📊', title: 'ATS Score Calculator',      desc: 'Instantly calculate how well your resume performs against Applicant Tracking Systems for your target role.' },
    { icon: '🎨', title: 'Custom Templates',           desc: 'Choose from professionally designed ATS-ready templates or craft your own unique layout from scratch.' },
    { icon: '🌐', title: 'Web Portfolio Generator',   desc: 'Transform your resume into a stunning web portfolio in minutes and publish it with a single click.' },
    { icon: '📄', title: 'Easy PDF Export',            desc: 'Export your polished resume as a high-quality PDF, perfectly formatted and ready to submit anywhere.' },
    { icon: '📈', title: 'Skill Analytics',            desc: 'Analyze your skill set, identify gaps, and receive role-specific recommendations to maximize your chances.' },
  ];

  const checkpoints = [
    'ATS-optimized templates trusted by top engineers',
    'Real-time skill gap analysis for your dream role',
    'One-click portfolio publishing',
    'Intelligent AI writing assistant built-in',
    'Role-specific keyword recommendations',
  ];

  const steps = [
    { num: '01', icon: '📝', title: 'Fill Your Details',     desc: 'Enter your experience, skills, and education in our smart guided form.' },
    { num: '02', icon: '🎨', title: 'Choose a Template',     desc: 'Pick from 6 professional ATS-ready designs that match your industry.' },
    { num: '03', icon: '🤖', title: 'AI Enhancement',        desc: 'Our NLP engine refines your bullets and scores your resume instantly.' },
    { num: '04', icon: '🚀', title: 'Export & Apply',         desc: 'Download your PDF or publish your portfolio with a single click.' },
  ];

  return (
    <div className="lp-root">

      {/* ══ NAVBAR ══ */}
      <nav className="lp-nav">
        <div className="lp-nav-inner">
          <a className="lp-logo" href="#top">
            <span className="lp-logo-mark">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L9.5 9.5 2 12l7.5 2.5L12 22l2.5-7.5L22 12l-7.5-2.5z" fill="white"/>
              </svg>
            </span>
            <span className="lp-logo-text">SkillFolio</span>
          </a>
          <div className="lp-nav-right">
            <button className="lp-nav-signin" onClick={onSignIn}>Sign In</button>
          </div>
        </div>
      </nav>

      {/* ══ HERO ══ */}
      <section className="lp-hero" id="top">
        <div className="lp-hero-inner">
          <div className="lp-hero-badge">
            <span className="lp-hero-badge-dot" />
            AI-Powered Resume Builder
          </div>
          <h1 className="lp-hero-h1">
            Build Resumes That<br/>
            <em>Get You Hired</em>
          </h1>
          <p className="lp-hero-sub">
            Create ATS-optimized resumes and stunning portfolios with
            intelligent AI assistance, real-time skill analytics, and
            professional templates — all in one place.
          </p>
          <button className="lp-hero-cta" onClick={onGetStarted}>
            Get Started Free →
          </button>
          <div className="lp-hero-trust">
            <div className="lp-hero-avatars">
              {['S','A','R','K'].map((l, i) => (
                <span key={i} className="lp-hero-av" style={{ background: ['#7C3AED','#9D5CF6','#6D28D9','#8B5CF6'][i] }}>{l}</span>
              ))}
            </div>
            <span>Trusted by 10,000+ engineers &amp; developers</span>
          </div>
        </div>
      </section>

      {/* ══ FEATURES ══ */}
      <section className="lp-features">
        <div className="lp-section-inner">
          <div className="lp-features-head reveal">
            <p className="lp-section-label">WHAT WE OFFER</p>
            <h2 className="lp-section-title">Everything You Need to<br/>Land Your Next Role</h2>
            <p className="lp-section-sub">SkillFolio combines intelligent tools to give you an unfair advantage in your job search.</p>
          </div>
          <div className="lp-features-grid">
            {features.map((f, i) => (
              <div className="lp-feat-card reveal" key={i} style={{ animationDelay: `${i * 0.07}s` }}>
                <span className="lp-feat-icon">{f.icon}</span>
                <h3 className="lp-feat-title">{f.title}</h3>
                <p className="lp-feat-desc">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ WHY SKILLFOLIO ══ */}
      <section className="lp-why">
        <div className="lp-section-inner lp-why-inner">
          <div className="lp-why-left reveal-left">
            <p className="lp-section-label">WHY SKILLFOLIO</p>
            <h2 className="lp-section-title">Built for Engineers,<br/>Designed to Impress</h2>
            <p className="lp-section-sub">
              We understand what technical recruiters look for. SkillFolio is
              built specifically for engineering and technology professionals
              who want to stand out.
            </p>
            <ul className="lp-why-list">
              {checkpoints.map((c, i) => (
                <li key={i} className="lp-why-item">
                  <span className="lp-why-check">✓</span>
                  {c}
                </li>
              ))}
            </ul>
            <button className="lp-why-cta" onClick={onGetStarted}>
              Start Building →
            </button>
          </div>

          <div className="lp-why-right reveal-right">
            {/* ATS Score browser mockup */}
            <div className="lp-ats-card">
              <div className="lp-ats-card-bar">
                <div className="lp-ats-dots">
                  <span style={{background:'#ff6058'}}/>
                  <span style={{background:'#ffbd2e'}}/>
                  <span style={{background:'#28ca41'}}/>
                </div>
                <span className="lp-ats-card-title">ATS Score Report</span>
              </div>
              <div className="lp-ats-card-body">
                {/* Circular score */}
                <div className="lp-ats-ring-wrap">
                  <svg width="110" height="110" viewBox="0 0 110 110">
                    <circle cx="55" cy="55" r="46" fill="none" stroke="#E5E7EB" strokeWidth="8"/>
                    <circle cx="55" cy="55" r="46" fill="none" stroke="#7C3AED" strokeWidth="8"
                      strokeDasharray="289" strokeDashoffset="46"
                      strokeLinecap="round" transform="rotate(-90 55 55)"
                      style={{animation:'atsRing 1.4s ease both'}}/>
                  </svg>
                  <div className="lp-ats-score-num">
                    <span className="lp-ats-big">88</span>
                    <span className="lp-ats-small">/100</span>
                  </div>
                </div>
                {/* Progress bars */}
                <div className="lp-ats-bars">
                  {[
                    { label: 'Skills Match', val: 85,  color: '#7C3AED' },
                    { label: 'Keywords',     val: 90,  color: '#14b8a6' },
                    { label: 'Format',       val: 95,  color: '#7C3AED' },
                    { label: 'Experience',   val: 78,  color: '#f59e0b' },
                  ].map((b, i) => (
                    <div className="lp-ats-bar-row" key={i}>
                      <span className="lp-ats-bar-label">{b.label}</span>
                      <div className="lp-ats-bar-track">
                        <div className="lp-ats-bar-fill" style={{ width:`${b.val}%`, background: b.color, animationDelay:`${i*0.15}s` }}/>
                      </div>
                      <span className="lp-ats-bar-pct">{b.val}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══ HOW IT WORKS ══ */}
      <section className="lp-steps">
        <div className="lp-section-inner">
          <div className="lp-steps-head reveal">
            <p className="lp-section-label">HOW IT WORKS</p>
            <h2 className="lp-section-title">From Zero to Hired<br/>in Four Steps</h2>
          </div>
          <div className="lp-steps-grid">
            {steps.map((s, i) => (
              <div className="lp-step-card reveal" key={i} style={{ animationDelay: `${i * 0.1}s` }}>
                <div className="lp-step-num">{s.num}</div>
                <div className="lp-step-icon-wrap"><span>{s.icon}</span></div>
                <h3 className="lp-step-title">{s.title}</h3>
                <p className="lp-step-desc">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ CTA ══ */}
      <section className="lp-cta">
        <div className="lp-cta-blob-1"/><div className="lp-cta-blob-2"/>
        <div className="lp-cta-inner reveal">
          <h2 className="lp-cta-title">Ready to Land Your<br/><em>Dream Job?</em></h2>
          <p className="lp-cta-sub">Join thousands of engineers who built their career with SkillFolio.</p>
          <div className="lp-cta-btns">
            <button className="lp-cta-primary" onClick={onGetStarted}>Get Started Free</button>
            <button className="lp-cta-outline" onClick={onSignIn}>Sign In</button>
          </div>
          <p className="lp-cta-fine">No credit card required <span>·</span> Free forever plan</p>
        </div>
      </section>

      {/* ══ FOOTER ══ */}
      <footer className="lp-footer">
        <div className="lp-footer-inner">
          <div className="lp-footer-brand">
            <div className="lp-footer-logo">
              <span className="lp-footer-logo-mark">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2L9.5 9.5 2 12l7.5 2.5L12 22l2.5-7.5L22 12l-7.5-2.5z" fill="white"/>
                </svg>
              </span>
              <span className="lp-footer-logo-text">SkillFolio</span>
            </div>
            <p className="lp-footer-desc">AI-powered resume and portfolio builder for engineering professionals.</p>
          </div>
          <div className="lp-footer-col">
            <p className="lp-footer-col-title">Product</p>
            <ul>
              <li><a href="#features">Features</a></li>
              <li><a href="#templates">Templates</a></li>
              <li><a href="#pricing">Pricing</a></li>
            </ul>
          </div>
          <div className="lp-footer-col">
            <p className="lp-footer-col-title">Company</p>
            <ul>
              <li><a href="#about">About</a></li>
              <li><a href="#blog">Blog</a></li>
              <li><a href="#contact">Contact</a></li>
            </ul>
          </div>
          <div className="lp-footer-col">
            <p className="lp-footer-col-title">Support</p>
            <ul>
              <li><a href="#docs">Docs</a></li>
              <li><a href="#faq">FAQ</a></li>
              <li><a href="#privacy">Privacy</a></li>
            </ul>
          </div>
        </div>
        <div className="lp-footer-bottom">
          <span>© 2025 SkillFolio. All rights reserved.</span>
          <span>SNDT Women's University · IT Department</span>
        </div>
      </footer>

      {/* ══ FLOATING AI BUTTON ══ */}
      <button
        className="lp-fab"
        onClick={onSignIn}
        onMouseEnter={e => {
          e.currentTarget.querySelector('.lp-fab-tooltip').style.opacity = '1';
          e.currentTarget.querySelector('.lp-fab-tooltip').style.transform = 'translateX(0)';
        }}
        onMouseLeave={e => {
          e.currentTarget.querySelector('.lp-fab-tooltip').style.opacity = '0';
          e.currentTarget.querySelector('.lp-fab-tooltip').style.transform = 'translateX(8px)';
        }}
      >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
          <path d="M12 2L9.5 9.5 2 12l7.5 2.5L12 22l2.5-7.5L22 12l-7.5-2.5z" fill="white"/>
        </svg>
        <span className="lp-fab-label">AI Assistant</span>
        <span className="lp-fab-tooltip">Try AI Assistant</span>
      </button>

    </div>
  );
}