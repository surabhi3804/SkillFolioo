import React, { useState, useEffect, useCallback, useRef } from "react";
import "./App.css";
import LandingPage       from "./LandingPage";
import Auth              from "./Auth";
import TemplateSelector  from "./TemplateSelector";
import DataCollection    from "./DataCollection";
import Chatbot           from "./Chatbot";
import SkillAnalytics    from "./SkillAnalytics";
import AtsScore          from "./AtsScore";
import Resumegenerator   from "./Resumegenerator";
import { authAPI, resumeAPI } from "./api";

const MODULES = [
  { id:"template",  label:"Template",  icon:"▣", title:"Template Selection",          sub:"MODULE 01 OF 6" },
  { id:"data",      label:"Data",      icon:"✦", title:"Data Collection",              sub:"MODULE 02 OF 6" },
  { id:"chatbot",   label:"AI Chat",   icon:"◉", title:"AI Content Enhancement",       sub:"MODULE 03 OF 6" },
  { id:"analytics", label:"Analytics", icon:"◈", title:"Skill Analytics",              sub:"MODULE 04 OF 6" },
  { id:"ats",       label:"ATS Score", icon:"✔", title:"ATS Score Evaluation",         sub:"MODULE 05 OF 6" },
  { id:"generate",  label:"Generate",  icon:"↗", title:"Resume & Portfolio Generator", sub:"MODULE 06 OF 6" },
];

function shapeResume(r) {
  return {
    personal:       r.personal       || {},
    summary:        r.summary        || {},
    experience:     r.experience     || [],
    education:      r.education      || [],
    skills:         r.skills         || [],
    projects:       r.projects       || [],
    certifications: r.certifications || [],
    extras:         r.extras         || {},
  };
}

function UserNav({ user, onLogout }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    function handler(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const initial = (user?.firstName || user?.email || "U").charAt(0).toUpperCase();

  return (
    <div ref={ref} style={{ position:"relative", display:"inline-flex", alignItems:"center" }}>
      <div onClick={() => setOpen(o => !o)} title={user?.email} style={{
        width:34, height:34, borderRadius:"50%",
        background:"var(--naval)", color:"var(--alabaster)",
        display:"flex", alignItems:"center", justifyContent:"center",
        fontSize:14, fontWeight:700, cursor:"pointer",
        border: open ? "2px solid var(--blush)" : "2px solid transparent",
        transition:"border-color .2s", fontFamily:"Jost,sans-serif",
      }}>
        {initial}
      </div>
      {open && (
        <div style={{
          position:"absolute", top:"calc(100% + 8px)", right:0, width:200,
          background:"white", border:"1px solid rgba(168,188,200,.25)",
          boxShadow:"0 20px 50px rgba(27,58,92,.15)", borderRadius:8, zIndex:600,
        }}>
          <div style={{ padding:"12px 14px", borderBottom:"1px solid rgba(168,188,200,.18)" }}>
            <div style={{ fontSize:13, fontWeight:700, color:"var(--naval)" }}>
              {user?.firstName} {user?.lastName}
            </div>
            <div style={{ fontSize:11, color:"rgba(27,58,92,.45)", marginTop:2 }}>
              {user?.email}
            </div>
          </div>
          <button onClick={() => { setOpen(false); onLogout(); }} style={{
            display:"flex", alignItems:"center", gap:9, width:"100%",
            padding:"10px 14px", background:"none", border:"none",
            fontFamily:"Jost,sans-serif", fontSize:12,
            color:"#c4614a", cursor:"pointer", textAlign:"left",
          }}>
            ↩ Sign Out
          </button>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [view,        setView]        = useState("landing");
  const [user,        setUser]        = useState(null);
  const [authModal,   setAuthModal]   = useState(null);
  const [active,      setActive]      = useState("template");
  const [resumeData,  setResumeData]  = useState(null);
  const [resumeId,    setResumeId]    = useState(null);
  const [selectedTpl, setSelectedTpl] = useState(null);
  const [saving,      setSaving]      = useState(false);
  const [saveMsg,     setSaveMsg]     = useState("");
  const saveTimer = useRef(null);

  const loadResumeFromBackend = useCallback(async () => {
    try {
      const data = await resumeAPI.get();
      if (data.resume) {
        setResumeId(data.resume._id);
        setResumeData(shapeResume(data.resume));
        if (data.resume.selectedTemplate) {
          setSelectedTpl({ id: data.resume.selectedTemplate });
        }
      }
    } catch (err) {
      console.error("Could not load resume:", err.message);
    }
  }, []);

  useEffect(() => {
    const storedUser = authAPI.getStoredUser();
    if (storedUser && authAPI.isLoggedIn()) {
      setUser(storedUser);
      setView("app");
      loadResumeFromBackend();
    }
  }, [loadResumeFromBackend]);

  const saveToBackend = useCallback(async (newData, tplId) => {
    if (!resumeId) return;
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      try {
        setSaving(true);
        console.log("💾 Saving resume", resumeId, newData);
        await resumeAPI.save(resumeId, {
          ...newData,
          selectedTemplate: tplId || selectedTpl?.id || "executive",
        });
        setSaveMsg("✓ Saved");
        setTimeout(() => setSaveMsg(""), 2000);
      } catch (err) {
        setSaveMsg("⚠ Save failed");
        setTimeout(() => setSaveMsg(""), 3000);
      } finally {
        setSaving(false);
      }
    }, 1500);
  }, [resumeId, selectedTpl]);

  const handleDataChange = useCallback((newData) => {
    setResumeData(newData);
    saveToBackend(newData, selectedTpl?.id);
  }, [saveToBackend, selectedTpl]);

  async function handleAuthSuccess(u,goToChatbot = false) {
    setUser(u);
    setAuthModal(null);
    setView("app");
    if (goToChatbot) setActive("chatbot");
    await loadResumeFromBackend();
  }

  function handleLogout() {
    authAPI.logout();
    clearTimeout(saveTimer.current);
    setUser(null);
    setResumeData(null);
    setResumeId(null);
    setSelectedTpl(null);
    setActive("template");
    setView("landing");
  }

  function handleTemplateSelect(tpl) {
    setSelectedTpl(tpl);
    setActive("data");
    if (resumeId) {
      resumeAPI.saveSection(resumeId, "selectedTemplate", tpl.id)
        .catch(err => console.error("Template save error:", err.message));
    }
  }

  const completion = resumeData ? Math.round(
    [resumeData.personal?.firstName,
     resumeData.summary?.summary,
     (resumeData.experience?.length  || 0) > 0,
     (resumeData.education?.length   || 0) > 0,
     (resumeData.skills?.length      || 0) >= 3,
    ].filter(Boolean).length / 5 * 100
  ) : 0;

  const ringR   = 16;
  const ringC   = 2 * Math.PI * ringR;
  const current = MODULES.find(m => m.id === active);

  if (view === "landing") return (
    <>
      <LandingPage
        onSignIn={() => setAuthModal("signin")}
        onGetStarted={() => user ? setView("app") : setAuthModal("signup")}
      />
      {authModal && <Auth mode={authModal} onClose={() => setAuthModal(null)} onSuccess={handleAuthSuccess}/>}
    </>
  );

  return (
    <>
      <div className="app-shell">
        <aside className="app-rail">
          <div className="rail-logo"><span style={{fontSize:11,letterSpacing:"-0.5px"}}>SF</span></div>
          {MODULES.map(m => (
            <button key={m.id}
              className={`rail-btn${active===m.id?" active":""}`}
              onClick={() => setActive(m.id)} title={m.title}>
              <span className="rail-btn-icon">{m.icon}</span>
              {m.label}
            </button>
          ))}
          <button className="rail-btn" style={{ marginTop:"auto" }}
            onClick={() => setView("landing")} title="Back to Home">
            <span className="rail-btn-icon">←</span>Home
          </button>
          <div className="rail-footer">
            <svg width="40" height="40" viewBox="0 0 40 40">
              <circle cx="20" cy="20" r={ringR} fill="none" stroke="rgba(244,238,232,.12)" strokeWidth="4"/>
              <circle cx="20" cy="20" r={ringR} fill="none"
                stroke={completion > 0 ? "var(--blush)" : "transparent"}
                strokeWidth="4" strokeDasharray={ringC}
                strokeDashoffset={ringC * (1 - completion / 100)}
                transform="rotate(-90 20 20)"
                style={{ transition:"stroke-dashoffset .5s ease" }}/>
              <text x="20" y="24" textAnchor="middle" fontSize="9"
                fill="rgba(244,238,232,.55)" fontFamily="Jost,sans-serif" fontWeight="700">
                {completion}%
              </text>
            </svg>
            <span className="rail-progress-label">Profile</span>
          </div>
        </aside>

        <header className="app-topbar">
          <div className="topbar-left">
            <div className="topbar-title">{current?.title}</div>
            <div className="topbar-subtitle">{current?.sub}</div>
          </div>
          <div className="topbar-right">
            {(saving || saveMsg) && (
              <span style={{
                fontSize:11, marginRight:12, fontFamily:"Jost,sans-serif",
                color: saveMsg.startsWith("⚠") ? "#c4614a" : "var(--windy)",
              }}>
                {saving ? "Saving…" : saveMsg}
              </span>
            )}
            <div className="topbar-dots">
              {MODULES.map(m => (
                <button key={m.id}
                  className={`topbar-dot${active===m.id?" active":""}`}
                  onClick={() => setActive(m.id)} title={m.title}/>
              ))}
            </div>
            <button className="topbar-generate" onClick={() => setActive("generate")}>Generate ↗</button>
            {user && <UserNav user={user} onLogout={handleLogout}/>}
 
          </div>
        </header>

        <main className="app-main">
          {active==="template"  && <TemplateSelector selectedId={selectedTpl?.id} onSelect={handleTemplateSelect}/>}
          {active==="data"      && <DataCollection key={resumeId || "new"} initialData={resumeData} onDataChange={handleDataChange}/>}
          {active==="chatbot"   && <Chatbot onUseText={(t,c) => console.log(c,t)}/>}
          {active==="analytics" && <SkillAnalytics skills={resumeData?.skills}/>}
          {active==="ats"       && <AtsScore resumeData={resumeData}/>}
          {active==="generate"  && <Resumegenerator resumeData={resumeData} selectedTemplate={selectedTpl}/>}
        </main>
      </div>
      {authModal && <Auth mode={authModal} onClose={() => setAuthModal(null)} onSuccess={handleAuthSuccess}/>}
    </>
  );
}